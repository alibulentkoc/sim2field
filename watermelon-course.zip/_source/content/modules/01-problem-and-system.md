# Module 1 — Harvesting Robotics: The Problem and the System

**Duration:** 3 hours (1.5 h lecture · 1.5 h demo + discussion)

## Learning outcomes

By the end of this module, students can:

1. Explain why heavy specialty fruit (watermelon, pumpkin) has resisted
   mechanization where grains and some vegetables have not.
2. Decompose an autonomous harvester into its five functional subsystems and
   state the role of each.
3. Trace the end-to-end "signal-to-action" data path from camera photons to a
   fruit in the bin.
4. Read a system-level requirement and classify it as functional, performance,
   or constraint.

## Core concepts

### Why this problem is hard

Watermelon and pumpkin sit at an awkward intersection of properties that defeats
both grain-style bulk mechanization and orchard-style robotic picking:

- **Mass.** A field watermelon is commonly 5–10 kg. That is roughly an order of
  magnitude heavier than the apples, strawberries, or peppers that most robotic
  harvesting research targets, and it pushes typical collaborative-robot arms
  past their rated payload. The manipulator cannot be an off-the-shelf cobot.
- **Camouflage.** A ripe melon is often the same green as its canopy, so simple
  color thresholding fails. Ripeness cues (ground-spot color, tendril dieback,
  sound) are subtle and partially hidden.
- **Occlusion.** Fruit grows under a dense, sprawling vine canopy on the ground,
  not presented at arm height on a trellis. The robot must often clear leaves
  before it can even see, let alone grasp.
- **Reproducibility.** One-off research rigs rarely survive contact with a
  commercial field and are nearly impossible for another lab to replicate, which
  is why so many promising prototypes never propagate.

Framing the difficulty precisely is the point: every later module exists to
defeat one of these four properties.

### The five subsystems

Any field harvester, ours included, decomposes into five cooperating subsystems:

1. **Mobility** — the platform that carries everything down the row and positions
   the tool. (Here: the Amiga rover, drive-over stance.)
2. **Perception** — cameras and algorithms that detect fruit, estimate ripeness,
   and localize the target in 3D. (Module 2.)
3. **Cognition / edge compute** — the on-board computer and the AI that turns
   perception into decisions and grasp commands under a no-cloud constraint.
   (Module 3.)
4. **Manipulation** — the arm and gripper that physically reach, grasp, lift, and
   place the fruit. (Module 4.)
5. **Supervision & integration** — the state machine, buses, safety interlocks,
   and power that make the four above behave as one machine. (Modules 5–6.)

### The signal-to-action path

The organizing thread of the whole course. Photons enter the camera; a detector
proposes fruit; a pose estimator places each fruit in the robot's coordinate
frame; the supervisor decides which to pick and drives the rover until that fruit
is at the pick station; a motion planner produces a collision-free, singularity-
aware arm trajectory; a grasp controller closes the gripper with a learned force;
the arm lifts and places; the cycle repeats. Latency, reliability, and power
accumulate along this path, and the machine is only as good as its weakest link.

### The drive-over architecture (our case study's key idea)

Rather than reaching *sideways* to a bed beside the rover, the Amiga *straddles*
the bed. The fruit passes through the open tool space beneath the frame as the
rover advances, and the arm picks it at a fixed station inside the wheelbase.
This one decision cascades into simplifications students will see repeatedly:
the camera's downward sight line stays clear of the arm; no reversing maneuver is
needed; and — most importantly — pick geometry is nearly identical for every
fruit, which is what makes learned grasping and tight cycle times achievable.

## Grad extension

Read one recent (past ~5 years) peer-reviewed paper on robotic harvesting of a
heavy or ground-grown crop. In one page, identify which of the four hard
properties the paper primarily attacks, what it trades away to do so, and whether
its result would transfer to watermelon. Bring it to the Module 2 discussion.

## Demo or lab

**Digital-twin walkthrough.** Open the browser digital twin
([`labs/lab-01-twin-tour.md`](../../labs/lab-01-twin-tour.md)). Run a full
harvest cycle. Students annotate — on paper or a shared doc — where each of the
five subsystems is visible in the running simulation, and mark the exact moment
in the cycle where each of the four hard properties is being addressed. This
grounds the abstractions in something moving on screen before any math appears.

## Knowledge check

1. Name the four fruit properties that make watermelon/pumpkin harvest hard to
   mechanize, and give one design consequence of each.
2. A requirement reads: *"The system shall place fruit in the collection bin with
   less than 5% incidence of visible bruising."* Classify it (functional /
   performance / constraint) and justify.
3. In the drive-over architecture, why does the camera sight line stay clear of
   the manipulator? Contrast with a side-reaching design.
4. Trace the signal-to-action path in your own words, naming at least six
   distinct stages.
5. Which subsystem would you expect to dominate the *power* budget, and which the
   *latency* budget? Defend your answer (you will revisit this in Module 3).

## Take-home assignment

Write a **one-page system brief** for a harvesting robot for a crop of *your*
choice other than watermelon or pumpkin (e.g., cabbage, cantaloupe, sweet
potato). Identify which of the four hard properties dominate, sketch the five
subsystems, and state three top-level requirements (one functional, one
performance, one constraint). This brief seeds your capstone crop if you want it
to. Deliverable: `assignments/m1-system-brief.md` in your own course fork.
