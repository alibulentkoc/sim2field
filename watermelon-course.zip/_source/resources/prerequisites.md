# Prerequisites & Self-Check

Use this before the course to place yourself and to identify what to brush up on.
None of these gate enrollment; they tell you where you'll need to lean on office
hours or the primers in `resources/`.

## Undergraduate self-check

You are ready if you can answer most of these without help:

- **Programming:** Can you read and write a Python function that loops over a list,
  calls a library, and returns a result? Can you install a package and run a
  script?
- **Linear algebra:** Can you compute a dot product and a matrix–vector product?
  Do you know what a rotation and a translation do to a point?
- **Physics/statics:** Can you draw a free-body diagram and reason about a lever
  arm and torque?
- **Datasheets:** Can you find a component's operating voltage, current draw, and
  interface from its datasheet?

If two or more are shaky, skim the primers linked in
[`resources/reading-list.md`](reading-list.md) before Module 2.

## Graduate self-check

In addition to the above, you should have real exposure to **at least one** of:

- **Computer vision** — convolution, a CNN, train/test splits, precision/recall.
- **Machine learning** — loss functions, overfitting, basic training loops.
- **Control systems** — feedback, a P/PID controller, stability intuition.
- **Robotics** — coordinate frames, forward/inverse kinematics, a manipulator
  Jacobian.

The graduate track assumes you can go deep in your area of strength and reach into
the others with the module material as a bridge.

## What the course does *not* assume

- No prior ROS experience (introduced in Module 5 at the level needed).
- No GPU/CUDA experience (introduced in Module 3; a CPU fallback path exists for
  every lab).
- No prior agricultural knowledge (the crop context is taught in Module 1).

## Recommended setup before Module 2

- A laptop that can run Python 3.10+ and a pretrained detector on CPU.
- Access to the browser digital twin (no install; runs in a modern browser).
- Optional but ideal: access to the course edge device (Jetson-class) for Module 3;
  otherwise the lab provides scaled reference numbers.
