# Assessment, Grading, and Rubrics

## Grading scheme (suggested)

Designed for a short course that rewards *doing* over memorizing. Adjust weights
to your institution's norms.

| Component | Weight | What it assesses |
|-----------|--------|------------------|
| Module knowledge checks (6) | 15% | Retention of core concepts; low-stakes, best-5-of-6 |
| Take-home assignments (6) | 30% | Applied skill; each produces a reusable artifact |
| Labs / demos participation | 10% | Hands-on engagement, incl. digital-twin work |
| Capstone project | 35% | Integrated, original engineering (see rubric) |
| Design-review participation | 10% | Critical engagement with peers' designs |

**Undergraduate vs. graduate.** Graduate students are held to the "research"
depth described in each module's grad extension and in the capstone; their
assignments and capstone are graded against the graduate rows of the rubrics
below. A common scheme with differentiated standards keeps a mixed-audience course
manageable.

## Assignment rubric (applies to each take-home)

| Criterion | Excellent (A) | Adequate (C) | Weak (F) |
|-----------|---------------|--------------|----------|
| **Technical correctness** | Equations/analysis correct; numbers check out | Minor errors that don't change conclusions | Fundamental errors |
| **Specificity** | Concrete, tied to the actual system/numbers | Somewhat generic | Vague, could describe any robot |
| **Justification** | Decisions defended with evidence/numbers | Asserted with weak support | Unsupported |
| **Artifact quality** | Clean, well-structured, reusable | Usable but rough | Incomplete/unusable |

## Capstone rubric

The capstone is scored out of 100. The governing principle: **quantitative
justification beats ambition.** A modest design defended with numbers outscores a
grand design defended with adjectives.

| Criterion | Pts | Excellent | Adequate | Weak |
|-----------|-----|-----------|----------|------|
| **Problem framing & requirements** | 15 | Sharp scope; measurable top-level reqs | Reasonable but loose | Unclear scope, unmeasurable reqs |
| **Technical design** | 25 | Correct, complete, appropriate to track | Mostly correct, gaps | Incorrect or superficial |
| **Design specification** | 10 | ≥ 5 verifiable, well-typed reqs | Present, some unverifiable | Missing/vague |
| **BOM excerpt** | 10 | Costed, sourced, reasoned | Present, thin reasoning | Missing/unrealistic |
| **Quantitative defense** | 20 | ≥ 3 decisions defended with numbers/budgets/trade studies | 1–2 defended | Description without numbers |
| **Validation evidence** | 10 | Twin/benchmark/analysis shows a req met | Partial evidence | None |
| **Risk & ethics note** | 5 | Real failure mode + mitigation + thoughtful deployment/ethics point | Present, shallow | Missing |
| **Design review (presentation)** | 5 | Clear, defends under questioning, owns risks | Adequate | Unclear/defensive |

**Graduate add-ons (folded into the above, raising the bar):** literature grounding
(≥ 3 peer-reviewed sources, design positioned vs. prior work), an explicitly
identified novel contribution, and a quantified trade study of ≥ 2 alternatives
for one key decision. A graduate capstone missing any of these cannot score in the
"Excellent" band for *Technical design* or *Quantitative defense*.

## Knowledge-check administration

- Deliver the multiple-choice set (in `quiz-bank.md`) through the existing HTML
  interface as an in-lesson check; auto-grade.
- Deliver the short-answer questions as brief written responses, graded lightly
  (correct/partial/incorrect) — their purpose is retrieval practice, not ranking.
- **Best-5-of-6** on module checks reduces anxiety and absorbs one bad week
  without derailing a short course.

## Academic-integrity note for an AI-rich course

This course *teaches* the use of AI tools (for perception, synthetic data, and the
digital twin), so a blanket "no AI" policy is incoherent. Recommended stance:
tools are permitted for exploration and drafting; **students must be able to
explain and defend every design decision and number in their submissions**, and
the design review (live Q&A) is where that understanding is verified. Assess
understanding, not keystrokes.
