# Lab 1 — Digital-Twin Walkthrough

**Module:** 1 · **Time:** 60–75 min · **Setup:** browser only (the course digital twin)

## Goal
Ground the five subsystems and the signal-to-action path in a running machine
before any math. Students leave able to point at every subsystem in a live sim.

## Before you start
Open the course digital twin in a modern browser. Confirm you can orbit the view,
open the control panel, and start/reset a harvest cycle.

## Steps
1. **Cold observation (10 min).** Run one full harvest with no explanation.
   Individually, write down everything the machine appears to do, in order.
2. **Map the five subsystems (20 min).** Reset. Using Module 1's subsystem list,
   label where each of the five (mobility, perception, cognition, manipulation,
   supervision) is visible. For cognition — invisible by nature — note where its
   *effects* appear (target lock, decisions, grasp force).
3. **Trace signal-to-action (20 min).** Step through one cycle slowly. At each
   stage, write which signal-to-action step is happening and its input/output.
4. **Spot the hard properties (15 min).** Identify the moment in the cycle where
   the machine addresses each hard property (mass, camouflage, occlusion,
   reproducibility). Some are structural rather than momentary — note which.

## Deliverable
A one-page annotated diagram or table linking sim events → subsystems →
signal-to-action steps. Submit to `assignments/m1-twin-tour.md`.

## Instructor notes
Observation before abstraction. Resist explaining the mechanism up front; let
students infer it, then reconcile in discussion. Common miss: students forget
cognition because it has no moving part — prompt them to find its fingerprints.
