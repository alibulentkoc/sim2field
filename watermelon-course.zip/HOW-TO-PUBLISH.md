# How to publish this website (2 minutes, Windows-friendly)

Your site is already built. `index.html` sits at the **root** of this repository,
which is exactly what GitHub Pages needs. You do **not** need GitHub Actions, a
workflow file, or any subfolder settings.

There are two ways to get this repo onto GitHub. Pick ONE.

---

## Path A — Replace your existing `watermelon` repo (recommended, cleanest)

This guarantees the files land at the root (the thing that has been going wrong).

**A1. Delete the old repo's contents isn't necessary — just recreate it fresh:**

1. Go to github.com → your `watermelon` repo → **Settings** → scroll to the very
   bottom → **Delete this repository** → confirm.
2. Click **+ (top right)** → **New repository** → Name: `watermelon` →
   **Public** → **Create repository**.

**A2. Upload the files at the ROOT (this is the important part):**

3. On the new empty repo page, click **uploading an existing file**.
4. Open the extracted `watermelon-course` folder on your PC. **Select ALL the
   files and folders INSIDE it** (index.html, demo.html, all the .html files,
   the `assets` folder, `_source`, etc.) — NOT the `watermelon-course` folder
   itself. Drag them into the browser.
   - ✅ Correct: after upload, the repo's main page lists **`index.html`**.
   - ❌ Wrong: the repo shows a single folder like `watermelon-course/` or
     `site/`. If you see that, delete and redo — the site must be at the root.
5. Click **Commit changes**.

**A3. Turn on Pages:**

6. **Settings** → **Pages**.
7. **Source** → **Deploy from a branch**.
8. **Branch** → **main**, folder → **/ (root)** → **Save**.
9. Wait about 1 minute, then open **https://alibulentkoc.github.io/watermelon/**.
   Refresh once or twice if it's not up yet.

Done. You should see the "Turn a camera frame into a grasped watermelon" home
page with the live simulation — not a plain README.

---

## Path B — Push with Git (if you prefer the command line)

This repo is already a Git repository with a commit on `main`.

```bash
cd watermelon-course
git remote add origin https://github.com/alibulentkoc/watermelon.git
git push -u origin main --force
```

(`--force` overwrites whatever is currently in the repo with this clean version.)

Then do **A3** above (Settings → Pages → Deploy from a branch → main → /root).

---

## How to know it worked
- The repo's main page lists `index.html` at the top level.
- Settings → Pages shows a green "Your site is live at …" banner.
- The URL shows the real site, not the README text.

## If you still see the README instead of the site
That means `index.html` is not at the repo root (it probably went inside a
subfolder during upload). Re-do step A2, selecting the files *inside* the folder,
not the folder itself.

## A note on privacy
A **public** repo on GitHub Pages produces a **public** website. If the material
must stay private, keep the repo private and view the site locally instead
(open `index.html`; for the embedded simulation run `python -m http.server` in
the folder and visit http://localhost:8000). Private Pages requires a paid plan.
