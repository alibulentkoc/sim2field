#!/usr/bin/env python3
"""Generate index.html (landing) and demo-page.html for the SIM2FIELD site."""
import os, html
from _build import shell, MODULES, CARD_BLURB

OUT = os.path.dirname(os.path.abspath(__file__))

# ---- module cards ----
cards = []
for i,(mid,mdpath,kicker,title,dur,has_demo) in enumerate(MODULES):
    demo_note = ' · live demo' if has_demo else ''
    cards.append(
      f'<a class="card" href="{mid}.html" style="text-decoration:none;border-bottom:1px solid var(--line)">'
      f'<div class="num">{kicker.upper()}</div>'
      f'<h3>{html.escape(title)}</h3>'
      f'<p>{html.escape(CARD_BLURB[mid])}</p>'
      f'<div class="foot"><span>◷ {dur}{demo_note}</span><span class="go">Open →</span></div>'
      f'</a>')
# capstone card (special)
cards.append(
  '<a class="card special" href="capstone.html" style="text-decoration:none">'
  '<div class="num">MODULE 7</div>'
  '<h3>Capstone Project</h3>'
  '<p>Design and defend an original harvesting subsystem — perception, manipulation, edge, or a whole-system concept for a new crop.</p>'
  '<div class="foot"><span>◷ 3h + independent</span><span class="go">Open →</span></div>'
  '</a>')
cards_html = '\n'.join(cards)

quick = [
  ('SPEC','Design Specification','spec-design.html'),
  ('BOM','Bill of Materials','spec-bom.html'),
  ('ARCH','Hardware & Software','spec-architecture.html'),
  ('MAP','Full Syllabus','syllabus.html'),
  ('GRADE','Assessment & Rubrics','rubrics.html'),
  ('PREP','Prerequisites','prerequisites.html'),
  ('READ','Reading List','reading-list.html'),
  ('TERMS','Glossary','glossary.html'),
]
quick_html = '\n'.join(
  f'<a href="{href}"><span class="k">{k}</span>{html.escape(label)}</a>' for k,label,href in quick)

hero = f"""
<header class="hero"><div class="hero-inner">
  <p class="eyebrow">Robotic Harvesting Systems · Short Course</p>
  <h1>Turn a camera frame into a <em>grasped watermelon</em> — in the field, with no cloud.</h1>
  <p class="lede">A practical, engineering-first course on the autonomous harvesting of heavy ground fruit.
  Seven modules follow the robot's own data path — perceive, decide, act, integrate, deploy — anchored to one
  fully specified machine you can drive in the browser below.</p>
  <div class="hero-cta">
    <a class="btn btn-primary" href="module-01.html">Start Module 1 →</a>
    <a class="btn btn-ghost" href="demo-page.html">Explore the live demo</a>
  </div>
  <div class="hero-meta">
    <div><span class="n">7</span><span class="l">Modules</span></div>
    <div><span class="n">~28h</span><span class="l">Contact time</span></div>
    <div><span class="n">6</span><span class="l">Labs + quizzes</span></div>
    <div><span class="n">UG + Grad</span><span class="l">Dual-level</span></div>
  </div>
</div></header>

<section class="demo-strip">
  <div class="demo-frame">
    <span class="demo-tag">● Live simulation — drive it</span>
    <iframe src="demo.html" title="Live harvester simulation" loading="lazy"></iframe>
  </div>
</section>
"""

modules_sec = f"""
<section id="modules">
  <div class="sec-head">
    <p class="eyebrow">The curriculum</p>
    <h2>Seven modules on a signal-to-action spine</h2>
    <p>Each module exists because the previous one created a need for it. Two carry the live simulation inline where it directly illustrates the engineering.</p>
  </div>
  <div class="cards">{cards_html}</div>
</section>

<section id="specs">
  <div class="sec-head">
    <p class="eyebrow">Engineering artifacts &amp; reference</p>
    <h2>Specs, reference, and assessment</h2>
    <p>The documents students read, emulate, and are graded against.</p>
  </div>
  <div class="quick">{quick_html}</div>
</section>
"""

body = hero + modules_sec
with open(os.path.join(OUT,'index.html'),'w',encoding='utf-8') as f:
    f.write(shell('SIM2FIELD — Robotic Harvesting Systems', body, active='Home'))

# ---- dedicated demo page ----
demo_body = """
<header class="article-head"><div class="inner">
  <p class="eyebrow">Interactive</p>
  <h1>Live Harvester Simulation</h1>
  <div class="dur">◷ Drag to orbit · drag the red gripper node to jog the mechanism · use the panel to run a harvest</div>
</div></header>
<section class="demo-strip" style="padding-top:30px">
  <div class="demo-frame" style="aspect-ratio:16/10">
    <span class="demo-tag">● Live — Amiga parallel 2-cylinder harvester</span>
    <iframe src="demo.html" title="Live harvester simulation"></iframe>
  </div>
</section>
<main class="page prose" style="padding-top:10px">
  <h2>What you're looking at</h2>
  <p>This is the fully simulated drive-over harvester used as the course case study. The rover straddles the
  crop bed; melons pass beneath the frame; a rail-mounted <strong>parallel two-cylinder mechanism</strong> picks
  each fruit at a fixed station inside the wheelbase and places it into the side trailer. The telemetry panel
  shows the live kinematics, singularity metric, and canopy-management state referenced throughout the modules.</p>
  <h3>Try this</h3>
  <ul>
    <li><strong>Run a harvest.</strong> Open the control panel (top-right) → Mission → <em>Start Harvest</em>, and watch the full DRIVE → STAGE → ALIGN → GRAB → LIFT → SWING → LOWER → RELEASE cycle (Module 4).</li>
    <li><strong>Jog the mechanism.</strong> Drag the red gripper node and watch the strut lengths and transmission angle γ update — the inverse kinematics from Module 4, live.</li>
    <li><strong>Widen the stance.</strong> Chassis → Track Width. The reachable workspace grows and γ improves, because the strut bases ride the rails — the co-design lesson in Module 4 and 5.</li>
    <li><strong>Aim the camera.</strong> Vision → Camera Pitch/Yaw/Height. The FOV cone and detection range follow the aim — the perception geometry in Module 2.</li>
    <li><strong>Switch canopy modes.</strong> Canopy Mgmt → Clearing Mode (brush / air knife / lifter fingers) — the sweep-and-segment strategy in Module 2 and 4.</li>
  </ul>
  <div class="pager">
    <a href="module-04.html"><span class="d">Related module</span>Module 4: Manipulation &amp; Control</a>
    <a class="next" href="module-02.html"><span class="d">Related module</span>Module 2: Vision &amp; Perception</a>
  </div>
</main>
"""
with open(os.path.join(OUT,'demo-page.html'),'w',encoding='utf-8') as f:
    f.write(shell('Live Demo — SIM2FIELD', demo_body, active='Live Demo'))

print('index.html + demo-page.html written')
