# Lab 2 — Perception on Real-ish Frames

**Module:** 2 · **Time:** ~3 h · **Setup:** laptop (CPU ok) or the edge device; Python 3.10+, a pretrained detector, the provided image set

## Goal
Run a detection pipeline end to end, measure it with the right metrics, and
perform the pixel → camera-3D → robot-3D handoff by hand.

## Provided
- An image set of melons in canopy under varied lighting (with labels).
- A camera intrinsics file: focal length `f`, principal point `(cx, cy)`, stereo
  baseline `b`, and an extrinsic `R, t` (camera → robot).

## Part A — Detection & metrics (75 min)
1. Run the pretrained detector over the image set.
2. Sweep the confidence threshold; at each, compute precision and recall against
   the labels. Plot the precision–recall curve.
3. Choose an operating threshold and justify it in two sentences (recall-weighted
   for yield vs. precision-weighted for cycle cost).

## Part B — The 3D handoff (60 min)
1. Pick one true detection at pixel `(u, v)` with its depth `Z`.
2. Compute camera-frame `X = (u−cx)·Z/f`, `Y = (v−cy)·Z/f`, `Z`.
3. Transform to the robot frame: `p_robot = R·p_camera + t`. Show the arithmetic.

## Part C — Occlusion gate (45 min)
1. Implement a simple occlusion metric (visible mask area ÷ expected full area, or
   overlapping-leaf count).
2. Set a gate threshold; report how many candidate picks it defers.
3. Argue whether your threshold is well chosen and what field evidence would tune
   it.

## Deliverable
`assignments/m2-perception-report.md`: the PR curve, three failure cases (one per
failure mode), the worked 3D handoff, and your gate analysis.

## Instructor notes
If no GPU is available, cap image resolution and note the scaled timing —
foreshadows the Module 3 edge budget. Emphasize that localization error, not mAP,
predicts grasp success.
