# Glossary

Terms as used in this course, in the harvesting-robot context.

**Bill of materials (BOM)** — a subsystem-organized list of hardware with
quantities and costs; read as a record of design decisions, not a shopping list.

**CAN bus** — a deterministic serial bus for real-time motor and safety traffic;
the control plane's backbone.

**Digital twin** — a simulation of the robot detailed enough to co-design
hardware, generate synthetic training data, and act as a regression test bed.

**Domain randomization** — training a model (often an RL policy) over randomized
simulation parameters so it transfers robustly to the real world.

**Drive-over architecture** — a design in which the rover straddles the crop bed
and the fruit passes beneath the frame to a fixed pick station, rather than the
arm reaching sideways.

**Edge computing** — running inference on the robot itself rather than in the
cloud; required here by the no-connectivity reality of fields.

**FMEA** — failure mode and effects analysis; a structured way to enumerate
failures, their effects, and mitigations.

**Grasp policy** — the controller that decides grip force and lift motion; in this
course a learned (RL) policy with a rule-based safety fallback.

**Inverse kinematics (IK)** — computing actuator commands from a desired end
position. For the case-study parallel mechanism, IK is the Euclidean distance
`Lᵢ = |G − Bᵢ|`.

**Keep-out volume** — a region the planned payload envelope must not enter (frame,
wheels, bin wall) during motion.

**Localization (3D)** — converting a 2D detection plus depth into a 3D position in
the robot's coordinate frame; the handoff from perception to manipulation.

**Occlusion gate** — a policy that declines to pick a fruit whose visible fraction
is below a threshold, deferring or clearing canopy instead.

**Parallel mechanism** — a manipulator whose actuators are grounded to the frame
and drive the end platform through struts; low moving mass, high stiffness.

**Precision / recall** — detection metrics: precision = fraction of detections
that are real; recall = fraction of real fruit detected. Recall protects yield;
precision protects cycles.

**Quantization** — representing a model's numbers in lower precision (INT8/FP16)
to cut latency/memory, at a small, validated accuracy cost.

**Real-time boundary** — the line between nodes that must meet deadlines (drive,
arm, safety) and best-effort nodes (detection, logging).

**ROS 2** — the robotics middleware providing the node/message architecture used
in the software stack.

**Safety monitor** — an independent process that can halt all motion regardless of
the mission state machine's state.

**Singularity (parallel)** — a configuration where struts become nearly collinear
and the mechanism loses force authority; tracked by the transmission angle γ.

**Sim-to-real** — transferring a model or policy trained in simulation to physical
hardware.

**Stereo disparity** — the pixel offset of the same point between two cameras;
inversely related to depth via `Z = f·b/d`.

**Supervisor / mission state machine** — the single component that owns
decisions and sequences the harvest cycle
(`DRIVE → STAGE → ALIGN → GRAB → LIFT → SWING → LOWER → RELEASE`).

**TensorRT** — an inference compiler that optimizes a model for a specific edge
device; often the largest practical speedup with no accuracy change.

**Transmission angle (γ)** — the angle between the two struts at the gripper node;
a live manipulability/singularity metric kept bounded away from 0°/180°.
