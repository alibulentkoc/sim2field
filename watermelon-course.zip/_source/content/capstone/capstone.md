# Module 7 — Capstone: Design a Harvesting Subsystem

**Duration:** 3 hours scheduled (in-class kickoff + reviews) plus independent work
across the back half of the course.

## Purpose

The capstone is where the course's threads converge into original engineering. A
student (or small team) designs a harvesting-robot **subsystem** — or a coherent
whole-system concept — and defends the design decisions **quantitatively**. It is
deliberately scoped so it can be completed with the digital twin, datasheets, and
analysis rather than a physical build, which keeps it achievable in a short course
while remaining genuinely demanding.

The take-home assignments from Modules 1–6 are the scaffolding: a student who did
them arrives at the capstone with a system brief, a perception report, an edge
plan, a manipulation analysis, a design packet, and a field-readiness plan. The
capstone assembles and deepens these into one defensible design.

## Choose a track

Pick the track that matches your interest and level. Undergraduates may take any
track at "concept" depth; graduate students take a track at "research" depth (see
grad requirements below).

- **Track A — Perception subsystem.** Design the detection + localization +
  ripeness pipeline for a stated crop and field condition. Deliver a model choice,
  a data strategy (including synthetic data), a measured or estimated accuracy and
  localization budget, and an occlusion-gate policy.
- **Track B — Manipulation subsystem.** Design an arm + gripper for a stated
  payload. Deliver the kinematics, workspace and singularity analysis, a DOF-
  reduction argument, a grasp strategy, and a state machine — validated in the
  twin.
- **Track C — Edge/compute subsystem.** Design the on-robot compute and ML
  deployment. Deliver a device choice, model-optimization plan, a reconciled
  latency/throughput/power budget, and the no-cloud control-loop boundary.
- **Track D — Whole-system concept for a new crop.** Adapt the full architecture
  to a crop other than watermelon/pumpkin (e.g., cabbage, cantaloupe, pumpkin if
  you studied watermelon). Deliver a scaled version of every artifact at concept
  depth, with the *changes* from the case study justified.

## Required deliverables

Every capstone, regardless of track, produces:

1. **Design brief (1–2 pp)** — the problem, the chosen crop/condition, top-level
   requirements, and the subsystem boundary.
2. **Technical design (4–8 pp)** — the core engineering: equations, diagrams,
   model/hardware choices, and the analysis specific to the track.
3. **Design specification (≥ 5 measurable requirements)** — functional,
   performance, and constraint, each verifiable.
4. **BOM excerpt** — the hardware in the student's subsystem, costed and sourced,
   in the course BOM format.
5. **Quantitative defense** — at least three design decisions defended with
   numbers (a budget, a trade study, a computed workspace, a measured accuracy).
6. **Validation evidence** — output from the digital twin, a benchmark, or a hand
   analysis showing the design meets a stated requirement.
7. **Risk & ethics note (½ p)** — the top failure mode, its mitigation, and one
   deployment/ethics consideration.

## Graduate ("research") requirements

Graduate capstones additionally require:

- A **literature grounding**: at least three peer-reviewed sources, with the
  design positioned relative to prior work.
- A **novel contribution**: a design choice, analysis, or method that goes beyond
  reproducing the case study, explicitly identified.
- A **critical trade study**: a quantified comparison of at least two alternatives
  for one key decision, with a recommendation.

## Suggested timeline

| When | Milestone |
|------|-----------|
| After Module 3 | Track chosen; design brief drafted (reuses M1 brief) |
| After Module 4 | Technical design core underway; twin validation begun |
| After Module 5 | Design spec + BOM excerpt + architecture drafted |
| After Module 6 | Risk/ethics note; full draft assembled |
| Final session | Design review presentation + submission |

## The design review

Each student/team presents a 10–12 minute design review to the class and
instructor, followed by questions. The review format mirrors industry: state the
requirement, show the design, defend it with data, own the risks. Peers submit
one substantive question each — engaging critically with a colleague's design is
itself assessed (see participation in the grading scheme).

## Grading

The capstone rubric is in
[`assessments/rubrics.md`](../../assessments/rubrics.md). In summary, the capstone
rewards **quantitative justification over description**: a design that is
plausible and defended with numbers outscores a more ambitious design defended
with adjectives.
