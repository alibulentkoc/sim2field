# Lab 6 — Safety and Deployment Workshop

**Module:** 6 · **Time:** ~1.5 h · **Setup:** discussion + worksheet

## Goal
Turn safety and deployment from slogans into a concrete test plan, a hazard
analysis, and a defensible ethics position.

## Part A — Build a staged test plan (30 min)
For the case-study robot, write the five test stages with an explicit *entry gate*
for each. Be specific about what metric must pass to advance to the field trial.

## Part B — Mini-FMEA on manipulation (30 min)
For the manipulation subsystem, list plausible failure modes, their effect on
people/crop/mission, a severity rating, and a mitigation. Derive the interlocks
the subsystem requires.

## Part C — Structured ethics debate (30 min)
Assigned-position debate on agricultural automation and labor, then open
discussion. Each student writes a one-paragraph defensible stance that steelmans
the opposing view.

## Deliverable
`assignments/m6-field-readiness.md`: the staged test plan, the mini-FMEA table,
and the ethics paragraph.

## Instructor notes
Keep the ethics segment rigorous, not performative: require each student to state
the strongest opposing argument before their own. The FMEA should produce
interlocks that trace back to the Module 5 architecture.
