# Lab 3 — Edge Budget and Optimization

**Module:** 3 · **Time:** ~2.5 h · **Setup:** Jetson-class edge device preferred; CPU fallback with provided reference numbers

## Goal
Measure a real inference workload, optimize it, and reconcile a latency/power
budget against a harvest-speed requirement.

## Part A — Benchmark (45 min)
1. Run the Module 2 detector on the edge device. Measure per-frame latency,
   sustained FPS, and (if instrumented) power draw.
2. Record the thermal behavior over a few minutes of sustained inference.

## Part B — Optimize (60 min)
1. Convert the model to FP16, then INT8 (quantization); recompile with the device
   runtime (e.g., TensorRT).
2. Re-measure latency, FPS, power, and accuracy on held-out data at each stage.
3. Plot accuracy vs. latency; mark the configuration you would ship.

## Part C — The loop budget (45 min)
1. Given detection + localization + decision times and a pick-station lead
   distance, compute the maximum rover speed at which the loop still resolves a
   target in time.
2. Identify the bottleneck stage and one realistic way to relieve it.

## Deliverable
`assignments/m3-edge-plan.md`: benchmark table, accuracy–latency plot, the loop
budget with max speed, and an explicit no-cloud control-loop boundary.

## Instructor notes
Watch for students optimizing accuracy in isolation. The teachable moment is a
config that is more accurate but thermally throttles — a lab bench win that is a
field loss.
