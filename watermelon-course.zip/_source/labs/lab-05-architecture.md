# Lab 5 — Architecture and Spec Workshop

**Module:** 5 · **Time:** ~2 h · **Setup:** whiteboard/diagram tool; the course spec, BOM, and architecture docs

## Goal
Practice the systems-engineering moves: draw architectures, write measurable
specs, and read a BOM critically.

## Part A — Redraw for a variant (45 min)
In teams, take a stated variant (add a second arm, or retarget to pumpkins).
Redraw both the hardware and software architecture. Mark the real-time boundary
and every bus. Identify the new bottleneck.

## Part B — Make specs measurable (40 min)
Given three weak requirements, rewrite each as a verifiable specification with a
quantity, threshold, and verification method. Tag each F / P / C.

## Part C — Audit the BOM (35 min)
Using `specs/bill-of-materials.md`: find the largest cost line and justify it;
find one single point of failure and propose a spare/dual-source; name the
cheapest change that most improves reliability.

## Deliverable
Team submission to `assignments/m5-architecture-workshop.md`: the two diagrams,
three rewritten specs, and the BOM audit.

## Instructor notes
Push teams to defend the CAN/Ethernet plane separation concretely — the variant
often tempts them to route inference over the control bus. That is the mistake to
surface.
