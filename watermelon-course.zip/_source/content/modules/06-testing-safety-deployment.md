# Module 6 — Field-Worthy: Testing, Safety, and Deployment

**Duration:** 3 hours (1.5 h lecture · 1.5 h workshop)

## Learning outcomes

By the end of this module, students can:

1. Design a staged test plan that moves a system from simulation to field with
   defensible gates between stages.
2. Apply a hazard-analysis mindset to a machine that operates near people and
   food, and specify appropriate safety interlocks.
3. Identify the ethical and labor dimensions of agricultural automation and
   discuss them without caricature.
4. Plan a real farm deployment: cooperator relationships, field logistics,
   maintenance, and data stewardship.

## Core concepts

### Testing as a staircase, not a leap

A field robot earns trust in stages, each with an entry gate that the previous
stage must satisfy:

1. **Simulation / digital twin** — kinematics, planner constraints, and the
   mission state machine are validated before hardware exists. Every later field
   anomaly is *reproduced here* and closed out before a hardware fix is attempted
   (the twin as regression test bed).
2. **Bench / subsystem** — each subsystem is tested in isolation against its
   interface spec: detector accuracy on held-out data, actuator stroke and force,
   grasp on sample fruit.
3. **Integrated bench** — subsystems combined under controlled conditions;
   integration hazards (timing, power, EMI, frames) surface here, indoors, where
   they are cheap.
4. **Controlled field** — a research plot with known fruit placement; measure
   harvest rate, grasp success, damage rate, and cycle time against spec.
5. **Commercial field trial** — a cooperating grower's production rows; the real
   test, with real variability and real consequences.

The pedagogy: **never skip a stair.** Most spectacular field failures are a
skipped bench test.

### Safety for a machine near people and food

Two audiences are at risk — people and the crop — and both belong in the hazard
analysis. Core practices:

- **Layered interlocks.** Physical e-stops; a **bumper lidar** or contact bumper
  that halts motion on obstacle detection; a **geofenced operating envelope** so
  the machine stops if it leaves its intended area. These are designed in from
  first fabrication, not retrofitted.
- **Independent safety monitor.** As established in Module 5, safety runs parallel
  to autonomy and can halt the machine regardless of the mission logic's state.
- **Fail-safe defaults.** Loss of power, signal, or a violated envelope should
  bring the machine to a safe stop, not an undefined state. A learned component
  degrades to a verified rule-based fallback, never to unpredictability.
- **Food safety.** Contact surfaces (gripper pads, bin) must be cleanable and
  food-appropriate; a bruised or punctured fruit is a quality and sometimes a
  contamination issue.

A simple hazard-analysis exercise (a lightweight FMEA — failure mode, effect,
mitigation) is the workshop deliverable.

### Ethics and the labor question — handled with care

Agricultural automation sits directly on a real and contested labor economy, and
students should engage it honestly rather than dismissively. The material presents
the range of views fairly:

- The **case for automation** cites chronic, worsening labor scarcity, the
  physical toll of stoop labor and heavy lifting, rising labor costs, and harvest
  windows missed for want of crews.
- The **concerns** cite displacement of seasonal agricultural workers,
  concentration of who can afford automation, and the risk that gains accrue to
  large operations while small growers are left behind.
- **Design responses** worth discussing: targeting tasks with genuine labor
  shortages rather than displacing willing workers; building on an **affordable,
  open platform** so that small and mid-sized growers — not only large operators —
  can adopt the technology; and creating higher-skilled local jobs (operators,
  maintainers) rather than only removing them.

The course does not prescribe a conclusion. It requires students to articulate the
trade-offs and take a defensible position, which is the appropriate stance for an
engineering ethics discussion.

### Deployment on a real farm

A prototype that works in a research plot is not yet deployable. Planning covers:

- **Cooperator relationships** — growers give row access, crop, and time; compensate
  them and respect that a failed run costs them yield.
- **Field logistics** — transport, charging, terrain, weather windows, and the
  reality that fields are muddy, dusty, and unforgiving of sealed-enclosure
  shortcuts.
- **Maintenance & spares** — field-replaceable components, documented procedures,
  and the humility that the arm *will* need servicing mid-season.
- **Data stewardship** — imagery of a grower's field is the grower's business;
  handle collection, storage, and any sharing responsibly and transparently.

## Grad extension

**Mini-FMEA.** Produce a failure-mode-and-effects analysis for one subsystem:
list plausible failure modes, their effects on people/crop/mission, a severity
rating, and a mitigation for each. Graduate students additionally write a
half-page position on one ethical trade-off in agricultural automation, citing at
least one source and steelmanning the view they ultimately disagree with.

## Demo or lab

**Lab 6 — Safety and deployment workshop.**
See [`labs/lab-06-safety-deploy.md`](../../labs/lab-06-safety-deploy.md). In teams:

1. Build a five-stage test plan for the case-study robot with an explicit entry
   gate for each stage.
2. Run a lightweight hazard analysis on the manipulation subsystem and specify
   the interlocks it requires.
3. Debate the labor/ethics question in structured form (assigned positions,
   then open), and each student writes a one-paragraph defensible stance.

## Knowledge check

1. List the five testing stages and give the entry gate for the field-trial
   stage.
2. Why must the safety monitor be able to halt the machine independent of the
   mission state machine? Give a scenario where mission logic alone would fail
   to stop.
3. Name three safety interlocks appropriate to this machine and the hazard each
   addresses.
4. State one substantive argument *for* and one *against* agricultural
   automation, and one design choice that responds to the concern.
5. Why is reproducing every field anomaly in the digital twin part of the *test*
   strategy, not just development?

## Take-home assignment

Produce a **two-page field-readiness plan** for your capstone concept: a staged
test plan with gates, a short hazard analysis with interlocks, a deployment
logistics checklist, and a one-paragraph ethics statement. Deliverable:
`assignments/m6-field-readiness.md`. Together with the M5 packet, this completes
the scaffolding for your capstone.
