# Design Specification — Case-Study Harvesting Robot

> **Teaching artifact.** This is a worked, illustrative specification for the
> course's case-study machine. Numbers are representative engineering targets
> chosen to make the document concrete and to give students something specific to
> critique and emulate — they are not vendor commitments. In the capstone,
> students write their own specification in this format.

## 1. How to read this document

Each requirement is tagged by type and given an ID:

- **[F]** Functional — *what the system does.*
- **[P]** Performance — *how well, measurably.*
- **[C]** Constraint — *a limit the design must respect.*

A requirement is well-formed only if it is **verifiable**: it names a quantity, a
threshold, and (ideally) a method of verification. Students should be able to
point at any requirement below and describe the test that would confirm it.

## 2. Operating context

The system harvests heavy ground-grown fruit (watermelon, 5–10 kg typical) from
single-row beds, in daylight, in Southeastern U.S. field conditions (heat, dust,
mud, variable cloud). It operates autonomously at a walking pace with a human
supervisor present.

## 3. System-level requirements

| ID | Type | Requirement |
|----|------|-------------|
| SYS-1 | [F] | The system shall autonomously detect, localize, grasp, lift, and place ripe fruit from a single crop bed into an on-board collection trailer. |
| SYS-2 | [P] | The system shall achieve a harvest success rate ≥ 85% of detectable ripe fruit in a controlled-field trial (≥ 100 fruit). |
| SYS-3 | [P] | The system shall place fruit with visible bruising in ≤ 5% of placed fruit, verified by instrumented firmness audit. |
| SYS-4 | [P] | The system shall sustain a pick-to-place cycle time ≤ 12 s per fruit at a rover advance speed ≥ 0.3 m/s (representative; students recompute for their design). |
| SYS-5 | [C] | The prototype hardware bill of materials shall not exceed a stated budget cap (course example: $50,000). |
| SYS-6 | [C] | The control loop shall have **no** cloud dependency; the system shall operate at full capability with zero network connectivity. |

## 4. Perception requirements

| ID | Type | Requirement |
|----|------|-------------|
| PER-1 | [F] | The perception subsystem shall detect fruit and estimate a ripeness decision (pick / skip) per candidate. |
| PER-2 | [P] | The 3D localization error of a committed target shall be ≤ 2 cm RMS in the robot frame at the pick station. |
| PER-3 | [F] | The subsystem shall compute an occlusion fraction per candidate and shall **not** commit to a pick above the occlusion gate (example threshold ≤ 34%). |
| PER-4 | [P] | Detection recall on ripe fruit shall be ≥ 0.90 on a held-out field-representative test set at the chosen operating threshold. |
| PER-5 | [C] | Perception shall function across the field illumination range (full sun to hard shade) without manual re-tuning between runs. |

## 5. Compute / edge requirements

| ID | Type | Requirement |
|----|------|-------------|
| CMP-1 | [P] | The perception→decision loop latency shall be low enough to resolve a target before it reaches the pick station at the maximum rated rover speed (student computes the bound). |
| CMP-2 | [C] | All real-time inference shall run on-robot (edge). Cloud may be used only for offline training and opportunistic, non-real-time telemetry sync. |
| CMP-3 | [C] | The compute enclosure shall not thermally throttle under sustained midday operation; the power/thermal budget shall include peak simultaneous actuator + inference load. |
| CMP-4 | [F] | Safety-critical control shall run on a separate real-time controller from best-effort perception. |

## 6. Manipulation requirements

| ID | Type | Requirement |
|----|------|-------------|
| MAN-1 | [F] | The manipulator shall position the gripper node to any commanded reachable target and grasp fruit at the bed centerline. |
| MAN-2 | [P] | The manipulator shall handle a payload up to 10 kg without exceeding actuator force limits at any pose in the workspace. |
| MAN-3 | [C] | The motion planner shall keep the mechanism's transmission angle γ bounded away from singularity (example: γ ≥ 15°) across all commanded motions. |
| MAN-4 | [C] | The planned payload envelope shall not enter defined keep-out volumes (frame, wheels, bin wall) during transfer. |
| MAN-5 | [F] | The grasp controller shall modulate grip force from tactile/load feedback and shall fall back to a verified rule-based controller on any out-of-envelope command. |

## 7. Integration, power, and safety requirements

| ID | Type | Requirement |
|----|------|-------------|
| INT-1 | [C] | Real-time motor and safety traffic shall use a deterministic bus (CAN) isolated from best-effort perception data traffic. |
| INT-2 | [F] | An independent safety monitor shall be able to halt all motion regardless of the mission state machine's state. |
| INT-3 | [F] | The system shall provide physical e-stop(s), obstacle-detection halt (bumper lidar/contact), and a geofenced operating envelope. |
| INT-4 | [C] | Loss of power, signal, or envelope shall bring the system to a defined safe stop, never an undefined state. |
| INT-5 | [C] | Fruit-contact surfaces shall be cleanable and food-appropriate. |

## 8. Verification methods (summary)

| Requirement class | Verification method |
|-------------------|---------------------|
| Detection/localization (PER) | Held-out labeled test set; measured error against ground truth |
| Cycle time / success / damage (SYS) | Controlled-field trial with instrumented audit |
| Latency / power / thermal (CMP) | Bench benchmark on target device under representative load |
| Kinematics / singularity / collision (MAN) | Digital-twin analysis + bench actuation test |
| Safety interlocks (INT) | Fault-injection test; each interlock triggered deliberately |

## 9. Student exercise

Choose any three requirements above and, for each, (a) confirm it is verifiable
and rewrite it if not, and (b) describe the exact test — sample size, apparatus,
pass/fail threshold — that would verify it. This exercise is the bridge from
Module 5 into the capstone specification deliverable.
