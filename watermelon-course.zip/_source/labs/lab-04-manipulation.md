# Lab 4 — Kinematics and the Constraint Envelope

**Module:** 4 · **Time:** ~2.5 h · **Setup:** browser digital twin + calculator/notebook

## Goal
Connect the closed-form parallel-mechanism kinematics to a live workspace, and
see singularity and collision constraints as real limits, not abstractions.

## Part A — IK by hand, then by twin (45 min)
1. For three target nodes `G`, compute `L₁, L₂` by hand from the strut bases.
2. Command each in the twin; confirm the displayed strut lengths match your
   arithmetic. Reconcile any discrepancy.

## Part B — Map the workspace (45 min)
1. Drag the gripper node to the edges where it stops (stroke limits). Sketch the
   reachable region — the overlap of the two stroke annuli.
2. Read the transmission angle γ at several poses; mark where γ is healthy vs.
   near-singular.

## Part C — Track width as a kinematic parameter (30 min)
1. Widen the track. Re-map the workspace and re-read γ at the drop pose.
2. Quantify: how much did reachable area grow, and how much did γ improve? Explain
   the coupling.

## Part D — The state machine (30 min)
1. Step one full grasp/place cycle. For each transition, write the guard that must
   hold and the collision the carry height prevents.

## Deliverable
`assignments/m4-manipulation-analysis.md`: the IK checks, a workspace sketch, the
γ observations, the track-width quantification, and the annotated state machine.

## Instructor notes
The "aha" is Part C: track width is simultaneously an agronomic and a kinematic
variable. Draw that connection explicitly — it is the module's best co-design
lesson.
