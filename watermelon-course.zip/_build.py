#!/usr/bin/env python3
"""
Build the SIM2FIELD course website from the course Markdown.
- Renders each module / spec / lab / resource page to styled HTML.
- Embeds the live Three.js harvester simulation (demo.html) on the demo page
  and inside Module 4 (manipulation) where it directly illustrates the content.
- Extracts the multiple-choice quiz set into an interactive, auto-graded widget
  and places the right questions on each module page.
- Generates an attractive index with module cards + quick links.
No external services; output is a static folder that works on GitHub Pages and
when opened locally.
"""
import os, re, json, html, markdown

ROOT = os.path.dirname(os.path.abspath(__file__))
COURSE = os.path.join(ROOT, '_source')
OUT = ROOT  # write pages into site/

MD = markdown.Markdown(extensions=['extra', 'tables', 'fenced_code', 'toc', 'sane_lists'])

def render_md(path):
    MD.reset()
    with open(path, encoding='utf-8') as f:
        return MD.convert(f.read())

def read(path):
    with open(path, encoding='utf-8') as f:
        return f.read()

# ---------------------------------------------------------------- nav / shell
NAV_LINKS = [
    ('Home', 'index.html'),
    ('Modules', 'index.html#modules'),
    ('Live Demo', 'demo-page.html'),
    ('Specs', 'index.html#specs'),
    ('Capstone', 'capstone.html'),
]

def shell(title, body, active='', extra_head='', extra_foot=''):
    links = ''.join(
        f'<a href="{href}"{" class=\"active\"" if lbl==active else ""}>{lbl}</a>'
        for lbl, href in NAV_LINKS)
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{html.escape(title)}</title>
<meta name="description" content="A short university course on the engineering of an autonomous watermelon/pumpkin harvesting robot: perception, edge AI, manipulation, and field deployment.">
<link rel="stylesheet" href="assets/style.css">
{extra_head}
</head>
<body>
<nav class="nav"><div class="nav-inner">
  <a class="brand" href="index.html"><span class="dot"></span>SIM2FIELD</a>
  <div class="nav-links">{links}</div>
</div></nav>
{body}
<footer class="foot"><div class="inner">
  <div>SIM2FIELD · Robotic Harvesting Systems — course materials</div>
  <div><a href="index.html">Home</a> · <a href="demo-page.html">Live Demo</a> · <a href="capstone.html">Capstone</a></div>
</div></footer>
{extra_foot}
</body>
</html>"""

# ---------------------------------------------------------------- quiz data
# Parsed from assessments/quiz-bank.md MC set, with per-question explanations.
QUIZZES = {
  'module-01': {
    'title': 'Module 1 — Knowledge Check',
    'questions': [
      {'q': 'The drive-over architecture primarily keeps clear:',
       'opts': ["the battery compartment","the camera's sight line to the fruit","the operator's seat","the CAN bus"],
       'a': 1, 'e': "Because the rover straddles the bed and the arm works beneath the frame, the downward camera view stays clear of the manipulator — unlike a side-reaching arm that swings through the camera's field."},
      {'q': 'In the case-study DOF reduction, fore/aft (x) positioning of the fruit is provided by:',
       'opts': ["a base yaw motor","the vehicle driving the fruit to a fixed station","the wrist joint","the gripper compliance"],
       'a': 1, 'e': "The vehicle supplies the x axis: it advances until the target reaches a fixed pick station, so the arm needs no fore/aft actuator."},
    ]},
  'module-02': {
    'title': 'Module 2 — Knowledge Check',
    'questions': [
      {'q': 'Stereo depth is Z = f·b/d. Doubling the distance to a fruit, all else equal, makes the disparity d:',
       'opts': ["roughly double","roughly half","unchanged","zero"],
       'a': 1, 'e': "Disparity is inversely proportional to depth, so twice the distance gives roughly half the disparity — which is why stereo depth degrades with range."},
      {'q': 'For a harvester, which metric most directly protects yield?',
       'opts': ["precision","recall","frame rate","model size"],
       'a': 1, 'e': "Recall measures how much ripe fruit is found; missed fruit is lost revenue. Precision protects wasted cycles, but recall protects yield."},
    ]},
  'module-03': {
    'title': 'Module 3 — Knowledge Check',
    'questions': [
      {'q': 'The strongest single reason for on-robot (edge) inference here:',
       'opts': ["it's cheaper than a server","fields lack reliable connectivity, so the control loop cannot depend on a network","edge devices are more accurate","it avoids writing training code"],
       'a': 1, 'e': "Connectivity is the hard blocker: a field has no guaranteed network, so a control loop that needs the cloud would stall. Latency and data-gravity are secondary."},
      {'q': 'Quantizing a model to INT8 most directly trades:',
       'opts': ["a small accuracy loss for large latency/memory gains","accuracy for higher resolution","power for cloud bandwidth","recall for precision, always"],
       'a': 0, 'e': "INT8 quantization cuts latency and memory substantially, usually at a small, must-be-validated accuracy cost."},
    ]},
  'module-04': {
    'title': 'Module 4 — Knowledge Check',
    'questions': [
      {'q': 'For the parallel two-cylinder mechanism, the inverse kinematics is:',
       'opts': ["a system of transcendental equations with two branches","the Euclidean distance from the node to each strut base, Lᵢ = |G − Bᵢ|","impossible in closed form","computed by the neural network"],
       'a': 1, 'e': "The actuator lengths ARE the task coordinates: each strut length is just the distance from the gripper node to that strut's base — no transcendental solve, no branch ambiguity."},
      {'q': 'The transmission angle γ approaching 0° indicates:',
       'opts': ["maximum stiffness","a parallel singularity with lost force authority","the workspace boundary is far away","the gripper is fully open"],
       'a': 1, 'e': "As the two struts become collinear (γ→0), the mechanism loses force authority perpendicular to them — a parallel singularity the planner must avoid."},
    ]},
  'module-05': {
    'title': 'Module 5 — Knowledge Check',
    'questions': [
      {'q': 'The safety monitor is architecturally placed:',
       'opts': ["as the final state of the mission state machine","inside the detector node","as an independent process that can halt motion regardless of mission state","on the cloud server"],
       'a': 2, 'e': "Safety must not depend on the correctness of the logic it protects against, so the monitor runs in parallel and can halt the machine no matter what state the supervisor believes it is in."},
      {'q': 'Why separate the CAN control plane from the Ethernet perception plane?',
       'opts': ["to save money on cabling","so a slow inference frame cannot stall a real-time safety loop","because cameras cannot use CAN","to allow cloud access"],
       'a': 1, 'e': "Keeping real-time motor/safety traffic on a deterministic bus, isolated from heavy perception data, guarantees the safety loop's timing."},
    ]},
  'module-06': {
    'title': 'Module 6 — Knowledge Check',
    'questions': [
      {'q': 'In the five-stage test plan, what is the entry gate for the commercial field trial?',
       'opts': ["a passing unit test","controlled-field metrics (success, damage, cycle time) meet spec","a signed grower contract","a full charge on the battery"],
       'a': 1, 'e': "You do not enter a grower's production rows until the controlled-field stage has demonstrated the machine meets its success, damage, and cycle-time specifications."},
      {'q': 'Which is a design response to the labor-displacement concern in ag automation?',
       'opts': ["making the platform as expensive as possible","building on an affordable, open platform so small and mid-sized growers can adopt it too","hiding the technology from workers","removing all human roles"],
       'a': 1, 'e': "An affordable, open platform spreads the benefit beyond large operations and can create higher-skilled local operator/maintainer roles rather than only removing jobs."},
    ]},
}

def quiz_widget(qid):
    data = QUIZZES[qid]
    qs = data['questions']
    qhtml = []
    for i, q in enumerate(qs):
        opts = ''.join(
            f'<button class="opt" data-q="{i}" data-o="{j}">{html.escape(o)}<span class="mark"></span></button>'
            for j, o in enumerate(q['opts']))
        qhtml.append(
            f'<div class="q" data-correct="{q["a"]}">'
            f'<p class="qtext"><span class="qn">{i+1:02d}</span>{html.escape(q["q"])}</p>'
            f'{opts}'
            f'<div class="qexpl"><b>Why:</b> {html.escape(q["e"])}</div>'
            f'</div>')
    return (
      f'<div class="quiz" data-quiz>'
      f'<div class="quiz-head"><span class="ic">◇</span>{html.escape(data["title"])}'
      f'<span class="score">0 / {len(qs)}</span></div>'
      f'{"".join(qhtml)}'
      f'<div class="quiz-foot"><button class="btn btn-dark" data-reset>Reset</button>'
      f'<span class="msg">Pick an answer to check it instantly.</span></div>'
      f'</div>')

QUIZ_JS = """
<script>
document.querySelectorAll('[data-quiz]').forEach(function(quiz){
  var total = quiz.querySelectorAll('.q').length;
  var answered = {};
  function refresh(){
    var correct = Object.values(answered).filter(Boolean).length;
    quiz.querySelector('.score').textContent = correct + ' / ' + total;
    var msg = quiz.querySelector('.msg');
    if (Object.keys(answered).length === total){
      msg.textContent = correct === total ? 'Perfect — all correct.' :
        'You got ' + correct + ' of ' + total + '. Review the explanations and try again.';
    }
  }
  quiz.querySelectorAll('.opt').forEach(function(btn){
    btn.addEventListener('click', function(){
      var qEl = btn.closest('.q');
      if (qEl.dataset.locked) return;
      qEl.dataset.locked = '1';
      var correct = parseInt(qEl.dataset.correct,10);
      var chosen = parseInt(btn.dataset.o,10);
      qEl.querySelectorAll('.opt').forEach(function(o){
        o.classList.add('locked');
        var oi = parseInt(o.dataset.o,10);
        if (oi === correct) o.classList.add('correct');
        else if (o === btn) o.classList.add('wrong');
      });
      qEl.querySelector('.qexpl').classList.add('show');
      answered[qEl.dataset.q || btn.dataset.q] = (chosen === correct);
      refresh();
    });
  });
  quiz.querySelector('[data-reset]').addEventListener('click', function(){
    answered = {};
    quiz.querySelectorAll('.q').forEach(function(qEl){
      delete qEl.dataset.locked;
      qEl.querySelectorAll('.opt').forEach(function(o){ o.className='opt'; });
      qEl.querySelector('.qexpl').classList.remove('show');
    });
    quiz.querySelector('.msg').textContent = 'Pick an answer to check it instantly.';
    refresh();
  });
});
</script>
"""

# ---------------------------------------------------------------- page specs
MODULES = [
  ('module-01','content/modules/01-problem-and-system.md','Module 1','The Problem & The System','3 hours', True),
  ('module-02','content/modules/02-vision-and-perception.md','Module 2','Machine Vision & Perception','5 hours', False),
  ('module-03','content/modules/03-edge-ml-ai.md','Module 3','Edge Computing, ML & AI','5 hours', False),
  ('module-04','content/modules/04-manipulation-and-control.md','Module 4','Manipulation & Control','5 hours', True),
  ('module-05','content/modules/05-integration-and-system-design.md','Module 5','Integration & System Design','4 hours', False),
  ('module-06','content/modules/06-testing-safety-deployment.md','Module 6','Testing, Safety & Deployment','3 hours', False),
]
CARD_BLURB = {
  'module-01':'Why heavy-fruit harvest resists mechanization, the five subsystems, and the signal-to-action path.',
  'module-02':'Detection, stereo depth, 3D localization, and the occlusion gate — finding a green melon in a green canopy.',
  'module-03':'On-robot inference under a no-cloud constraint: latency/power budgets, model optimization, learned grasping.',
  'module-04':'Parallel-mechanism kinematics, workspace and singularities, DOF reduction, and the grasp/place cycle.',
  'module-05':'Hardware and software architecture, measurable specs, the BOM, and the integration hazards that emerge.',
  'module-06':'Staged testing, safety interlocks, the labor/ethics debate, and real farm deployment.',
}

EMBED_HTML = (
  '<div class="embed"><div class="bar"><span class="live"></span>LIVE SIMULATION — '
  'AMIGA PARALLEL 2-CYLINDER HARVESTER'
  '<a href="demo.html" target="_blank" rel="noopener">Open full screen ↗</a></div>'
  '<iframe src="demo.html" title="Harvester simulation" loading="lazy"></iframe></div>')

def inject_tags(body_html):
    """Add small colored pills before the standard module section headers."""
    reps = [
      (r'(<h2[^>]*>)(\s*Grad extension)', r'\1<span class="tagpill tag-grad">Graduate</span>\2'),
      (r'(<h2[^>]*>)(\s*Demo or lab)', r'\1<span class="tagpill tag-lab">Hands-on</span>\2'),
      (r'(<h2[^>]*>)(\s*Knowledge check)', r'\1<span class="tagpill tag-quiz">Quiz</span>\2'),
      (r'(<h2[^>]*>)(\s*Take-home[^<]*)', r'\1<span class="tagpill tag-take">Assignment</span>\2'),
    ]
    for pat, rep in reps:
        body_html = re.sub(pat, rep, body_html)
    return body_html

def build_module(mid, mdpath, kicker, title, dur, has_demo, prev_link, next_link):
    body_html = render_md(os.path.join(COURSE, mdpath))
    body_html = inject_tags(body_html)
    # strip the leading H1 (we render our own header)
    body_html = re.sub(r'^\s*<h1[^>]*>.*?</h1>', '', body_html, count=1, flags=re.S)
    # strip the "Duration:" strong line (shown in header instead)
    body_html = re.sub(r'<p><strong>Duration:.*?</p>', '', body_html, count=1, flags=re.S)

    # place the live sim right after the "Demo or lab" heading on demo-bearing modules
    if has_demo:
        body_html = re.sub(r'(<h2[^>]*>\s*<span class="tagpill tag-lab">.*?</h2>)',
                           r'\1' + EMBED_HTML, body_html, count=1, flags=re.S)

    # replace the "Knowledge check" list with the interactive quiz, if we have one
    quiz = quiz_widget(mid) if mid in QUIZZES else ''
    if quiz:
        # insert the interactive quiz right after the Knowledge check heading;
        # keep the written questions below for instructors/self-testers.
        body_html = re.sub(r'(<h2[^>]*>\s*<span class="tagpill tag-quiz">.*?</h2>)',
                           r'\1' + quiz, body_html, count=1, flags=re.S)

    pager = '<div class="pager">'
    if prev_link: pager += f'<a href="{prev_link[1]}"><span class="d">← Previous</span>{html.escape(prev_link[0])}</a>'
    if next_link: pager += f'<a class="next" href="{next_link[1]}"><span class="d">Next →</span>{html.escape(next_link[0])}</a>'
    pager += '</div>'

    header = (
      f'<header class="article-head"><div class="inner">'
      f'<p class="eyebrow">{html.escape(kicker)}</p>'
      f'<h1>{html.escape(title)}</h1>'
      f'<div class="dur">◷ {html.escape(dur)}</div>'
      f'</div></header>')
    page = f'{header}<main class="page prose">{body_html}{pager}</main>'
    return shell(f'{title} — SIM2FIELD', page, active='Modules', extra_foot=QUIZ_JS)

def build_simple(mdpath, kicker, title, active=''):
    body_html = render_md(os.path.join(COURSE, mdpath))
    body_html = inject_tags(body_html)
    body_html = re.sub(r'^\s*<h1[^>]*>.*?</h1>', '', body_html, count=1, flags=re.S)
    header = (
      f'<header class="article-head"><div class="inner">'
      f'<p class="eyebrow">{html.escape(kicker)}</p>'
      f'<h1>{html.escape(title)}</h1></div></header>')
    page = f'{header}<main class="page prose">{body_html}</main>'
    return shell(f'{title} — SIM2FIELD', page, active=active)

# ---------------------------------------------------------------- write pages
written = []

# modules with prev/next
for i,(mid,mdpath,kicker,title,dur,has_demo) in enumerate(MODULES):
    prev_link = None
    nxt = None
    if i>0:
        pm=MODULES[i-1]; prev_link=(f'{pm[2]}: {pm[3]}', f'{pm[0]}.html')
    if i<len(MODULES)-1:
        nm=MODULES[i+1]; nxt=(f'{nm[2]}: {nm[3]}', f'{nm[0]}.html')
    else:
        nxt=('Capstone Project','capstone.html')
    out=f'{mid}.html'
    with open(os.path.join(OUT,out),'w',encoding='utf-8') as f:
        f.write(build_module(mid,mdpath,kicker,title,dur,has_demo,prev_link,nxt))
    written.append(out)

# capstone
with open(os.path.join(OUT,'capstone.html'),'w',encoding='utf-8') as f:
    f.write(build_simple('content/capstone/capstone.md','Module 7','Capstone: Design a Harvesting Subsystem',active='Capstone'))
written.append('capstone.html')

# specs + resources simple pages
SIMPLE=[
  ('specs/design-specification.md','Specification','Design Specification','Specs','spec-design.html'),
  ('specs/bill-of-materials.md','Specification','Bill of Materials','Specs','spec-bom.html'),
  ('specs/architecture.md','Specification','Hardware & Software Architecture','Specs','spec-architecture.html'),
  ('content/syllabus.md','Overview','Syllabus','Modules','syllabus.html'),
  ('resources/reading-list.md','Resources','Reading List & Resources','','reading-list.html'),
  ('resources/glossary.md','Resources','Glossary','','glossary.html'),
  ('resources/prerequisites.md','Resources','Prerequisites & Self-Check','','prerequisites.html'),
  ('assessments/rubrics.md','Assessment','Assessment & Rubrics','','rubrics.html'),
]
for mdpath,kicker,title,active,out in SIMPLE:
    with open(os.path.join(OUT,out),'w',encoding='utf-8') as f:
        f.write(build_simple(mdpath,kicker,title,active))
    written.append(out)

print('pages written:', len(written))
print('\n'.join(written))
