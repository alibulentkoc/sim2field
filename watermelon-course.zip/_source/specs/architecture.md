# Software and Hardware Architecture

> **Teaching artifact.** A reference architecture for the case-study machine,
> written so students can copy the *structure* into their own capstone design and
> so instructors can point at concrete decisions. ASCII diagrams are used
> intentionally so the file renders anywhere and diffs cleanly in Git.

## 1. Hardware architecture

### 1.1 Reference block diagram

```
                         ┌──────────────────────────────────────────────┐
                         │                 POWER DOMAIN                  │
                         │  Battery → DC distribution → per-domain fuses │
                         └───────┬───────────────┬───────────────┬──────┘
                                 │               │               │
                    ┌────────────▼───┐   ┌───────▼────────┐  ┌───▼──────────┐
   PERCEPTION PLANE │  Edge module   │   │ Platform Brain │  │  Actuation   │
   (Ethernet/USB)   │  (Jetson-class)│   │  (real-time)   │  │  power stage │
                    │  detection,    │   │  drive, CAN,   │  │  actuator    │
                    │  localization, │   │  safety,       │  │  drives      │
                    │  grasp policy  │   │  supervisor    │  │              │
                    └───┬────────┬───┘   └───┬────────┬───┘  └──────┬───────┘
                        │        │           │        │             │
        ┌───────────────▼──┐  ┌──▼───────────▼─┐   ┌──▼─────────────▼──────────┐
        │  Stereo head,    │  │  ── CAN bus ──  │   │  Telescopic struts (×2),  │
        │  wrist cam, NIR  │  │  motors, encoders,│  │  gripper (load cells +    │
        │  (front toolbar) │  │  safety I/O, RTK  │  │  tactile), canopy tool    │
        └──────────────────┘  └─────────────────┘   └───────────────────────────┘
                                       │
                              ┌────────▼─────────┐
                              │  Safety layer:   │
                              │  e-stop, bumper  │
                              │  lidar, geofence │
                              └──────────────────┘
```

### 1.2 The one decision to remember

**Two compute planes, deliberately separated.**

- A **real-time control plane** on the platform Brain: drive control, the CAN bus,
  the safety monitor, and the mission supervisor. Deterministic, safety-critical.
- A **best-effort perception plane** on the edge module: detection, localization,
  and the grasp policy. Compute-heavy, latency-tolerant relative to safety.

They communicate through a defined interface (a ROS 2 bridge), but a slow
inference frame can **never** stall a safety loop, because they do not share the
real-time bus. This separation is the architectural spine of a dependable field
robot and students should be able to defend it.

### 1.3 Bus assignments

| Bus | Carries | Why |
|-----|---------|-----|
| **CAN** | motor commands, encoder feedback, safety I/O | deterministic, robust, native to the platform |
| **Ethernet / USB** | camera streams, inference data, ROS 2 topics | high bandwidth for pixels and model I/O |
| **Discrete lines** | e-stop, interlocks | independent of software; fail-safe |

## 2. Software architecture

### 2.1 Node/message graph (ROS 2-style)

```
 [camera driver] ──img──▶ [detector] ──dets──▶ [localizer] ──3D target──▶ [SUPERVISOR]
                                                                              │  ▲
                                                                     commands │  │ state/telemetry
                                                                              ▼  │
     [grasp policy] ◀──tactile/load── [arm controller] ◀──arm cmd── [SUPERVISOR]
                                                                              │
                                             ┌────────────────┬───────────────┤
                                             ▼                ▼               ▼
                                     [drive controller] [arm controller] [SAFETY MONITOR]
                                             │                │               │ (independent)
                                             └──────── CAN ───┴───────────────┘
```

### 2.2 The supervisor and the mission state machine

The **supervisor** is the single place decisions are made. It owns the mission
state machine:

```
 DRIVE ─▶ STAGE ─▶ ALIGN ─▶ GRAB ─▶ LIFT ─▶ SWING ─▶ LOWER ─▶ RELEASE ─┐
   ▲                                                                    │
   └──────────────────────────  next fruit  ◀───────────────────────────┘
```

Each transition has a **guard** (a condition that must hold to advance) — e.g.,
`GRAB → LIFT` waits on a tactile/force condition; `RELEASE` fires only over a
valid bin slot. A stuck guard is a designed-for condition (timeout → recovery),
not an afterthought.

### 2.3 The safety monitor is not a state

Critically, the **safety monitor runs in parallel** to the mission state machine
and can halt all motion regardless of what state the supervisor believes it is
in. Drawing it *inside* the FSM would be a design error: safety must not depend on
the correctness of the logic it is protecting against.

### 2.4 The real-time boundary

```
 ── best-effort (miss a deadline → degraded, not dangerous) ──
   detector · localizer · logging · telemetry sync
 ─────────────────────────── boundary ───────────────────────
 ── real-time (miss a deadline → unsafe) ──
   drive control · arm control · safety monitor
```

Design nodes on each side to their appropriate standard. Best-effort nodes must
never be placed where a missed deadline becomes a safety event.

## 3. Software stack recommendations

A credible, modern, and largely open stack for the course and capstone:

| Layer | Recommendation | Note |
|-------|----------------|------|
| Middleware | **ROS 2** (e.g., Humble/Jazzy LTS) | node graph, messaging, tooling; the field standard |
| Real-time / platform | farm-ng Amiga SDK + **CAN** | native drive/safety integration |
| Perception models | **PyTorch** for training; **YOLO-family** detector or instance segmenter | mature, well-documented |
| Edge runtime | **TensorRT** (compile), **ONNX** (interchange), **CUDA/cuDNN** | the optimization path from Module 3 |
| RL / grasp policy | a standard RL framework + the digital twin for sim training | domain randomization; rule-based fallback |
| Simulation / twin | the browser kinematic twin (course) + a physics engine (e.g., Isaac/Gazebo) for contact | twin as design + regression tool |
| Data / MLOps | dataset versioning, experiment tracking, held-out field test sets | reproducibility discipline |
| Languages | **Python** (perception, ML, glue); **C++** (real-time nodes) | right tool per plane |

**Guidance for students:** prefer boring, well-supported, open components. A field
robot is not the place to adopt three bleeding-edge frameworks at once — every
dependency is a maintenance and reliability liability in a machine that must run
in the mud for a season.

## 4. Architecture exercises

1. Redraw the hardware diagram for a **two-arm** variant. What changes on each
   bus and plane? Where is the new bottleneck?
2. Move one node across the real-time boundary (either direction) and explain the
   consequence.
3. The grasp policy needs tactile data at high rate. Which plane does it live on,
   and how does its data reach the real-time arm controller without violating the
   separation?
