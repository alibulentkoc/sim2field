# Reading List & Resources

> Curated by topic rather than exhaustively. Prefer primary sources (peer-reviewed
> papers, official docs) over blogs. Because the field moves quickly, treat any
> specific model or tool as a *representative* of its category and check for the
> current best-in-class when you teach the course. Graduate students should pull
> recent (past ~3–5 years) papers for the capstone literature grounding.

## Foundations — robotics & manipulation

- A standard robotics textbook covering coordinate frames, forward/inverse
  kinematics, and manipulator Jacobians (e.g., a widely used *Introduction to
  Robotics* / *Modern Robotics* text). Read the kinematics and workspace chapters
  before Module 4.
- Reference material on **parallel mechanisms** and their singularities — the
  transmission-angle concept central to Module 4.

## Machine vision & perception

- A computer-vision text or course covering detection, segmentation, and the
  precision/recall/mAP metric family.
- Documentation for a current single-stage detector family (YOLO-lineage) and an
  instance-segmentation model, for the Module 2 lab.
- Stereo vision fundamentals: disparity, the `Z = f·b/d` relationship, and
  calibration/extrinsics.
- Survey literature on **agricultural perception** and fruit detection under
  occlusion and variable illumination (for the grad extension and capstone).

## Edge computing, ML & AI

- Official documentation for the target edge platform (NVIDIA Jetson family) and
  its inference stack (TensorRT, CUDA/cuDNN), plus the ONNX interchange format.
- Material on **model optimization**: quantization (INT8/FP16), pruning, and
  knowledge distillation, with attention to accuracy validation after
  optimization.
- Introductory **deep reinforcement learning** material, and reading on
  **sim-to-real transfer** and **domain randomization** for robotic grasping.
- Background on **synthetic data** generation, including diffusion-based
  augmentation and neural-field scene reconstruction (NeRF / Gaussian splatting)
  as used for training-data expansion.

## Systems, ROS, and integration

- **ROS 2** official tutorials and concept docs (nodes, topics, executors,
  real-time considerations).
- The **farm-ng Amiga** developer documentation and SDK for the platform,
  CAN integration, and the Brain controller.
- Reference reading on **CAN bus** fundamentals for the real-time control plane.

## Safety, testing, and deployment

- An introduction to **FMEA** (failure mode and effects analysis) for the Module 6
  hazard-analysis workshop.
- Material on **machine safety** for mobile/autonomous equipment (e-stops,
  interlocks, functional-safety mindset) at an introductory level.
- Extension/industry reporting on **agricultural labor** economics and the
  automation debate, chosen to represent multiple perspectives fairly for the
  ethics discussion.

## Course-internal artifacts

- The browser **digital twin** — the primary interactive resource, used in Labs
  1, 4, and the capstone.
- [`specs/design-specification.md`](../specs/design-specification.md) — worked
  specification to read and emulate.
- [`specs/bill-of-materials.md`](../specs/bill-of-materials.md) — worked BOM.
- [`specs/architecture.md`](../specs/architecture.md) — reference hardware/software
  architecture.
- [`resources/glossary.md`](glossary.md) — terms used across the course.

## A note on citing sources in student work

Because this repository is private and course-specific, fill in the exact
editions, URLs, and DOIs your program prefers when you instantiate the course.
The categories above are deliberately tool-agnostic so the reading list ages
gracefully; the instructor localizes them to current best sources at teaching
time.
