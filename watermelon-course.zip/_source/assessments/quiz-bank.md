# Quiz Bank & Answer Keys

> Instructor copy. Each module's knowledge check is reproduced here with a model
> answer or answer sketch. In the student-facing HTML interface, present the
> questions without the answers; keep this file out of any student build.
> A short auto-gradable multiple-choice set is included at the end for use as
> in-interface knowledge checks.

---

## Module 1 — Problem and System

1. **Four hard properties + a consequence each.** Mass (→ off-the-shelf cobots
   under-rated; needs purpose-built manipulator); camouflage (→ color thresholds
   fail; needs learned/multi-modal perception); occlusion (→ can't see/grasp;
   needs canopy clearing + occlusion gate); reproducibility (→ one-offs don't
   propagate; needs open commercial platform).
2. **Classify the bruising requirement.** Performance — it states a measurable
   quality threshold (≤ 5%) that can be verified by audit.
3. **Camera clear of arm.** In drive-over, the arm picks *beneath/inside* the
   frame while the camera looks down the corridor ahead; sight line and arm
   occupy different spaces. A side-reach arm swings through the camera's field.
4. **Signal-to-action path.** Photons → detection → 3D localization → target
   selection/decision → drive to pick station → motion planning → grasp (learned
   force) → lift → place → repeat. (≥ 6 stages named.)
5. **Power vs latency dominance.** Power: mobility/actuation (motors) typically
   dominate; Latency: perception→decision loop dominates. Accept defended
   variants.

## Module 2 — Vision and Perception

1. **Stereo depth eqn + falloff.** `Z = f·b/d`. Disparity `d` shrinks with
   distance, so a fixed pixel error causes a larger depth error far away →
   accuracy degrades with range.
2. **Compute X,Y,Z.** `Z = 0.85`; `X = (410−320)·0.85/700 = 0.109 m`;
   `Y = (300−240)·0.85/700 = 0.073 m`. So ≈ (0.109, 0.073, 0.85) m.
3. **Great mAP, poor grasp.** Causes: (a) large 3D localization error (test:
   compare estimated vs. measured position); (b) depth noise/occluded fruit
   center (test: correlate grasp failures with occlusion or depth variance).
4. **Occlusion gate; raise threshold.** The gate defers picks on fruit too hidden
   to grasp reliably. Raising it lets more fruit through (↑ yield) but includes
   worse-seen fruit → more mis-grasps/bruising (↓ quality).
5. **Recall vs precision.** Generally recall (missed fruit = lost yield). Flips
   when mis-grasps are costly/damaging or cycle time is scarce — then precision
   matters more.

## Module 3 — Edge, ML, AI

1. **Edge over cloud, ranked.** Connectivity (no network in fields) > latency (no
   round trip in a fast loop) > reliability/data-gravity. Defend ranking:
   connectivity is a hard blocker; the others are severe but conditional.
2. **Is the loop fast enough?** Loop = 40+8+5 = 53 ms. In 53 ms at 0.8 m/s the
   rover moves ≈ 0.042 m — far less than the 1.2 m lead. Yes, comfortably; the
   bottleneck stage is detection (40 ms).
3. **INT8 trade.** Good when latency/thermal-limited and 1.5% accuracy is within
   margin (most field runs). Bad when that 1.5% crosses a recall floor that costs
   real yield, or near a safety-relevant decision.
4. **Keep rule-based grasp.** A learned policy can emit out-of-envelope commands;
   in a food/near-people machine it must degrade to a *verified* controller, not
   undefined behavior. Framed as failure-mode containment, not performance.
5. **Twin reduces labeling; a risk.** Renders labeled scenes + augmentation → many
   rare cases without hand-labeling. Risk: sim-to-real gap — synthetic artifacts
   the model overfits; mitigate with domain randomization + real held-out tests.

## Module 4 — Manipulation and Control

1. **Parallel for heavy payload.** Actuators ground to frame (low moving mass);
   struts share load → stiffer, less whip under 5–10 kg.
2. **Compute L₁,L₂.** With `B₁=(−0.85,1.75)`, `B₂=(0.85,1.75)`, `G=(0,0.45)`:
   `L₁ = √(0.85² + 1.30²) = √(0.7225+1.69) = √2.4125 ≈ 1.553 m`; by symmetry
   `L₂ ≈ 1.553 m`.
3. **Transmission angle γ.** Angle between the struts at the node. As `γ→0` the
   struts become collinear → no force authority perpendicular to them (parallel
   singularity); planner keeps γ bounded away (e.g., ≥ 15°).
4. **Where each axis went.** x-position → vehicle; along-row scatter → paddle
   width; wrist tilt → gravity-plumb head; base yaw/transfer → in-plane stroke.
5. **Common carry height.** Both occur high enough that the payload envelope
   clears the keep-out corridor (rail/wheels/bin wall); prevents the fruit/fingers
   striking the bin wall during lateral transfer.

## Module 5 — Integration and System Design

1. **Separate CAN from Ethernet.** A slow/large perception frame on a shared bus
   could delay a safety/motor message → missed deadline. Separation guarantees the
   real-time loop's timing.
2. **Safety monitor outside FSM.** Safety must not depend on the correctness of
   the mission logic; an independent monitor halts the machine even if the FSM is
   wedged or wrong.
3. **Rewrite "see fruit well."** e.g., *"Detection recall ≥ 0.90 on ripe fruit
   across the field illumination range (full sun to hard shade) on a held-out test
   set, with no manual re-tuning between runs."*
4. **Three integration hazards + fixes.** Timing (bus loading → budget & separate
   planes); power (inrush + inference spike → per-domain fusing, headroom); EMI
   (motor noise into signal lines → routing/shielding). Also accept frames/
   mechanical fit.
5. **Buying a platform is a decision.** Trades some customization for
   reproducibility, support, and schedule certainty; makes the system replicable
   by other labs — a downstream consequence beyond cost.

## Module 6 — Testing, Safety, Deployment

1. **Five stages; field-trial gate.** Sim → bench/subsystem → integrated bench →
   controlled field → commercial trial. Field-trial gate: controlled-field metrics
   (success, damage, cycle time) meet spec.
2. **Independent halt scenario.** If the supervisor mis-tracks state (e.g., thinks
   it's idle while an actuator is moving), mission logic won't stop it; an
   independent monitor watching motion/obstacles still halts.
3. **Three interlocks + hazard.** E-stop (human intervention); bumper lidar/contact
   (collision with person/object); geofence (leaving safe area). Accept fail-safe
   power/signal loss.
4. **For/against + design response.** For: labor scarcity, physical toll, missed
   windows. Against: worker displacement, unequal access. Response: open/affordable
   platform so small growers benefit; target genuine shortages; create maintainer
   roles.
5. **Twin as test strategy.** Reproducing every field anomaly in sim and closing it
   there before a hardware fix makes the twin a regression test bed — anomalies
   can't silently reappear.

---

## Auto-gradable multiple-choice set (for the HTML interface)

*(single correct answer; correct option marked with ✅ in this instructor copy)*

**MC-1.** The drive-over architecture primarily keeps clear:
- a) the battery compartment
- b) the camera's sight line to the fruit ✅
- c) the operator's seat
- d) the CAN bus

**MC-2.** Stereo depth `Z = f·b/d`. Doubling the distance to a fruit, all else
equal, makes the disparity `d`:
- a) roughly double
- b) roughly half ✅
- c) unchanged
- d) zero

**MC-3.** The strongest single reason for on-robot (edge) inference here:
- a) it's cheaper than a server
- b) fields lack reliable connectivity, so the control loop cannot depend on a network ✅
- c) edge devices are more accurate
- d) it avoids writing training code

**MC-4.** For the parallel two-cylinder mechanism, the inverse kinematics is:
- a) a system of transcendental equations with two branches
- b) the Euclidean distance from the node to each strut base, `Lᵢ = |G − Bᵢ|` ✅
- c) impossible in closed form
- d) computed by the neural network

**MC-5.** The transmission angle γ approaching 0° indicates:
- a) maximum stiffness
- b) a parallel singularity with lost force authority ✅
- c) the workspace boundary is far away
- d) the gripper is fully open

**MC-6.** The safety monitor is architecturally placed:
- a) as the final state of the mission state machine
- b) inside the detector node
- c) as an independent process that can halt motion regardless of mission state ✅
- d) on the cloud server

**MC-7.** Quantizing a model to INT8 most directly trades:
- a) a small accuracy loss for large latency/memory gains ✅
- b) accuracy for higher resolution
- c) power for cloud bandwidth
- d) recall for precision, always

**MC-8.** In the case-study DOF reduction, fore/aft (x) positioning of the fruit
is provided by:
- a) a base yaw motor
- b) the vehicle driving the fruit to a fixed station ✅
- c) the wrist joint
- d) the gripper compliance
