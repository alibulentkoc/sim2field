# Module 3 — Deciding on the Robot: Edge Computing, ML, and AI

**Duration:** 5 hours (2.5 h lecture · 2.5 h lab)

## Learning outcomes

By the end of this module, students can:

1. Justify why a field harvester runs inference **on the robot** and articulate
   the no-cloud constraint in terms of latency, connectivity, and reliability.
2. Build a latency, throughput, and power budget for an on-robot perception +
   decision loop and check it against a cycle-time requirement.
3. Explain model optimization for the edge — quantization, pruning, and
   compilation (e.g., TensorRT) — and the accuracy/latency trade each makes.
4. Describe how a learned grasp policy is trained in simulation and transferred
   to hardware, and why a rule-based fallback is retained.
5. Explain the role of synthetic data and a digital twin in building a field ML
   system before hardware exists.

## Core concepts

### Why edge, not cloud

A harvester works in rural fields where connectivity is intermittent at best. If
the control loop depended on a remote server, a dropped signal would stall the
machine mid-grasp. Three arguments, in order of decisiveness:

1. **Connectivity** — you cannot assume a network in a field; the machine must
   harvest at full capability with **zero** connectivity.
2. **Latency** — a perception→decision loop that must keep pace with a moving
   rover cannot afford a network round trip; the budget is tens of milliseconds,
   not hundreds.
3. **Reliability & data gravity** — camera streams are large and continuous;
   moving pixels off-robot is wasteful when the decision must be made locally
   anyway.

The design rule for the course: **no cloud dependency in the control loop.**
Cloud is allowed for offline model training and opportunistic telemetry sync when
a network happens to be available — never for a real-time decision.

### Budgeting the loop (the quantitative heart of the module)

Students build three budgets and reconcile them against a target cycle time.

- **Latency budget.** Sum the per-stage times: image acquisition → detection →
  localization → decision → motion-plan handoff. If the rover advances at a
  walking pace and fruit must be picked at a fixed station, the perception loop
  must resolve a target well before it reaches the station. Worked example in the
  lab: given a detector at *X* ms/frame on the edge device and a rover speed, is
  the loop fast enough? If not, what do you cut?
- **Throughput budget.** Frames per second the pipeline sustains vs. frames per
  second needed for smooth tracking. Batching, resolution, and model size are the
  knobs.
- **Power/thermal budget.** The edge device draws watts that become heat under a
  sealed, sun-exposed enclosure. A model that is 10% more accurate but doubles
  power may be the wrong choice if it thermally throttles at midday — a failure
  that never appears in a lab benchmark.

The lesson students carry out: **accuracy is not the only axis.** A field ML
system is chosen on the joint surface of accuracy, latency, power, and thermal
headroom.

### Making models fit the edge

Off-the-shelf models rarely meet an edge budget as trained. The standard toolkit:

- **Quantization** — represent weights/activations in INT8 (or FP16) instead of
  FP32. Large latency and memory wins, usually small accuracy cost; must be
  validated on *your* data.
- **Pruning / distillation** — remove redundant weights or train a small "student"
  model to mimic a large "teacher." Trades capacity for speed.
- **Compilation** — a runtime such as TensorRT fuses layers and picks
  hardware-optimal kernels for the specific device (e.g., a Jetson Orin-class
  module). Often the single biggest practical speedup, with no accuracy change.

The workflow: train large and accurate offline, then quantize + compile for the
target, then **re-measure accuracy on held-out field data** before trusting it.

### Learned grasping, with a safety net

Grasping a heavy, slick, variably shaped fruit without bruising it is hard to
hand-code. Modern approach: a **deep-reinforcement-learning grasp policy** that
modulates grip force and lift trajectory in real time from tactile and load-cell
feedback — tightening on incipient slip, easing before the bruising threshold.

Two ideas make this credible rather than buzzword:

- **Sim-to-real with domain randomization.** The policy is trained in a
  contact-augmented digital twin over randomized fruit mass, rind stiffness, and
  surface friction, so it learns a robust behavior rather than overfitting one
  melon. The reward is grounded in *post-harvest quality* (from instrumented
  firmness audits), not a proxy.
- **A verified fallback.** A conservative rule-based force controller is retained
  and can take over if the learned policy produces an out-of-envelope command.
  In a machine handling food near people, a learned component should degrade to a
  trusted one, never to undefined behavior.

### Synthetic data and the digital twin

You cannot photograph ten thousand partially buried, mud-obscured melons before
building the robot — so you generate them. A browser/engine digital twin renders
labeled scenes; diffusion-based augmentation adds photorealistic texture, soil
splatter, and lighting/weather shifts; neural-field reconstructions (NeRF /
Gaussian splatting) of real rows add geometric realism. The twin doubles as a
**regression test bed**: every field anomaly is reproduced in simulation, added
to the training corpus, and closed out before a hardware fix is attempted. This
is how a small team builds a field-robust model without a season of hand-labeling.

## Grad extension

**Quantify a real trade.** Take a provided model in FP32; quantize to INT8 and
compile for the course edge device. Report the latency, throughput, power, and
accuracy at each stage on held-out data, and write a short recommendation:
which configuration ships, and what field condition would change your answer?
Graduate students additionally critique the reward design for the grasp policy —
what does "grounded in post-harvest quality" require of the data collection?

## Demo or lab

**Lab 3 — Edge budget and optimization.**
See [`labs/lab-03-edge.md`](../../labs/lab-03-edge.md). On the course edge device
(Jetson-class, or a CPU fallback with scaled numbers):

1. Benchmark the Module 2 detector: latency, FPS, and power draw.
2. Apply FP16/INT8 and re-measure; plot the accuracy-vs-latency trade.
3. Build the latency budget for a given rover speed and pick station distance;
   determine the maximum sustainable harvest speed and identify the bottleneck
   stage.

## Knowledge check

1. Give the three arguments for edge over cloud inference here, ranked, and
   defend your ranking.
2. Detection takes 40 ms, localization 8 ms, decision 5 ms on the edge device.
   The rover moves at 0.8 m/s and must resolve a target 1.2 m before the pick
   station. Is the loop fast enough? Show the reasoning.
3. Quantizing to INT8 cut latency 3× and accuracy 1.5%. Under what field
   condition is that a good trade, and under what condition is it not?
4. Why is a rule-based grasp controller retained alongside a superior learned
   policy? Frame the answer in terms of failure modes, not performance.
5. Explain how a digital twin reduces the amount of hand-labeled field data
   needed, and name one risk of relying on synthetic data.

## Take-home assignment

Produce a **one-page edge deployment plan** for the perception + grasp stack:
chosen device, model configuration (precision, compilation), your measured or
estimated latency/power budget, and the no-cloud control-loop boundary drawn
explicitly (what runs on-robot vs. what may sync opportunistically). Deliverable:
`assignments/m3-edge-plan.md`.
