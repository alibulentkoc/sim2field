# Bill of Materials — Case-Study Harvesting Robot

> **Teaching artifact.** This BOM is organized to teach how to *read and reason
> about* a hardware budget, not to place an order. Prices are representative
> planning estimates (USD); real procurement requires current vendor quotes.
> The example totals to a **$50,000** prototype cap to mirror a realistic funded
> research budget. In the capstone, students produce a BOM excerpt for their own
> subsystem in this format.

## How to read a BOM as an engineering document

A bill of materials makes design decisions legible. As you read, ask:

- **Where does cost concentrate?** (Here: the platform. That is deliberate — see
  the note below.)
- **What is commercial-off-the-shelf (COTS) vs. fabricated?** COTS is faster and
  replaceable; fabricated is custom but a schedule and sourcing risk.
- **What is a single point of failure?** An item with no backup whose failure
  stops the machine.
- **What would you dual-source or spare?** The cheapest insurance against a
  season-ending delay.

## BOM by subsystem

| Subsystem | Item | Qty | Est. unit (USD) | Est. line (USD) |
|-----------|------|-----|-----------------|-----------------|
| **Mobility** | farm-ng Amiga rover, research config (adjustable 36–90 in. track, 4WD hub motors) | 1 | 21,000 | 21,000 |
| **Mobility** | Amiga Intelligence Kit (Brain compute, RTK-GNSS, dashboard, CAN microcontroller kit) | 1 | 6,500 | 6,500 |
| **Vision** | Stereo depth cameras, row-detection head (e.g., Luxonis OAK-D Pro W PoE) | 2 | 600 | 1,200 |
| **Vision** | Close-range wrist camera, grasp verification (e.g., Intel RealSense D405) | 1 | 450 | 450 |
| **Vision** | Near-infrared rind-reflectance imaging module (maturity spectra) | 1 | 1,800 | 1,800 |
| **Manipulation** | IP66 multi-stage telescopic linear actuators w/ encoders (rail-mounted strut pair) | 2 | 2,025 | 4,050 |
| **Manipulation** | Servo drives, CAN nodes, motion-control microcontrollers | 1 | 1,200 | 1,200 |
| **Manipulation** | Portal-rail strut mounts, gripper head, node hardware fabrication (6061/7075, machining, clevises, pins, bearings) | 1 | 3,150 | 3,150 |
| **Manipulation** | Compliant paddle gripper w/ load cells + piezoresistive tactile array (DRL grasp control) | 1 | 2,600 | 2,600 |
| **Canopy** | Canopy-mgmt module: rotary brush, air-knife blower, lifter fingers, wrist puff nozzle, slip clutch, floating mount, current-sensing driver | 1 | 1,200 | 1,200 |
| **Logistics** | Side-towed collection trailer: padded slotted bin, offset drawbar hitch, encoder wheels | 1 | 2,000 | 2,000 |
| **Compute** | Edge-AI module for offline inference (NVIDIA Jetson Orin NX class), PoE switch, field radio link | 1 | 1,600 | 1,600 |
| **Safety** | Solid-state 3D lidar (canopy structure + bumper safety), e-stops, beacons, guarding | 1 | 1,350 | 1,350 |
| **Support** | Batteries, chargers, cabling, connectors, field spares | 1 | 1,300 | 1,300 |
| **Support** | Field instrumentation: fruit firmness tester, scales, data-logging weather node | 1 | 600 | 600 |
| **Vision** | (reserved / contingency and integration hardware) | 1 | 200 | 200 |
| | | | **Total** | **50,000** |

*(Line values are illustrative and chosen to sum to the cap; adjust with real
quotes. The point for students is the structure and the reasoning, not the exact
cents.)*

## Reading notes — the decisions this BOM encodes

- **The platform is the largest line, on purpose.** Buying a commercially
  supported, open rover rather than fabricating a one-off chassis is what makes
  the whole system *replicable* by another lab. The cost buys reproducibility and
  schedule certainty — a legitimate engineering trade, not an extravagance.
- **Manipulation cost sits in actuation and fabrication, not motors everywhere.**
  Because the design reduced actuated DOF to two frame-mounted struts, there are
  only two large actuators to buy — a direct budget consequence of the Module 4
  design idea.
- **Vision is multi-modal but modest.** Stereo + close-range + NIR covers the
  same-color camouflage problem without an exotic sensor suite.
- **Safety and compute are small line items with outsized importance.** Cheap to
  buy, expensive to omit — a recurring lesson.

## Student exercises

1. **Cost concentration.** What fraction of the BOM is the platform? Argue whether
   that concentration is a strength or a risk for a research prototype.
2. **Single point of failure.** Identify the item whose failure most likely stops
   a harvest, and propose a spare or dual-source strategy within a stated budget.
3. **Cheapest reliability win.** Name the single lowest-cost change that most
   improves field reliability, and justify it.
4. **Crop swap.** If you retargeted this BOM from watermelon to pumpkin, which
   lines change and why? (Consider mass, geometry, and canopy.)
