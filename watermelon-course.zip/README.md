# Robotic Harvesting Systems — SIM2FIELD

A short university course on the engineering of an autonomous watermelon/pumpkin
harvesting robot: **perception, edge AI, manipulation, and field deployment.**
Upper-division undergraduate + first-year graduate · 7 modules · ~28 hours.

### ▶ Live site
Once GitHub Pages is enabled (see `HOW-TO-PUBLISH.md`), the site is at:
**https://alibulentkoc.github.io/watermelon/**

The website includes a distinctive landing page, a **live 3-D harvester simulation
you can drive in the browser**, and an **interactive auto-graded quiz on every
module** — plus the full curriculum, specs, BOM, architecture, and capstone.

### What's in this repository
| Path | What it is |
|------|------------|
| `index.html` | Website home page (this is what GitHub Pages serves) |
| `demo.html` | The Three.js harvester simulation |
| `demo-page.html` | Full-screen simulation + guided walkthrough |
| `module-01.html` … `module-06.html` | The six teaching modules (with embedded demo + quizzes) |
| `capstone.html` | The capstone project |
| `spec-*.html`, `syllabus.html`, `rubrics.html`, … | Specs, reference, assessment pages |
| `assets/style.css` | Site design system |
| `_source/` | The original course **content in Markdown** (edit here, then rebuild) |
| `_build.py`, `_build_index.py` | Scripts that regenerate the site from `_source/` |
| `HOW-TO-PUBLISH.md` | Two-minute guide to get the site live |

### Editing the content later
Edit the Markdown under `_source/`, then rebuild the pages:
```bash
python _build.py && python _build_index.py     # needs: pip install markdown
```
The generated pages are committed, so you only rebuild when you change content.
