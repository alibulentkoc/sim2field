# Module 2 — Seeing the Fruit: Machine Vision and Perception

**Duration:** 5 hours (2 h lecture · 3 h lab)

## Learning outcomes

By the end of this module, students can:

1. Distinguish the tasks in a perception pipeline — detection, segmentation,
   ripeness classification, and 3D localization — and explain what each
   contributes.
2. Explain how a stereo camera recovers depth and compute a 3D fruit position in
   the robot frame from a pixel detection plus depth.
3. Diagnose the dominant field failure modes — occlusion, same-color camouflage,
   variable illumination — and match each to a mitigation.
4. Define and apply an occlusion gate and explain why a harvester should decline
   to pick a fruit it cannot see well enough.
5. Evaluate a detector with the right metrics (precision/recall, mAP, IoU) and
   argue which matters most for this application.

## Core concepts

### The perception pipeline

Perception is not one model; it is a small pipeline, each stage feeding the next:

1. **Detection** — locate candidate fruit in the image (bounding boxes or
   masks). Modern practice: a single-stage CNN detector (YOLO-family) or an
   instance-segmentation model (Mask R-CNN, or a transformer-based segmenter)
   when per-pixel masks help downstream grasping.
2. **Ripeness / quality classification** — decide whether a detected fruit
   should be picked. For melons this fuses visual cues (ground-spot color, rind
   pattern) and, in advanced builds, near-infrared reflectance that correlates
   with maturity.
3. **3D localization** — convert the 2D detection into a 3D position in the
   robot's coordinate frame, using stereo depth. This is what the arm actually
   consumes.
4. **Occlusion assessment** — quantify how much of the fruit is hidden by canopy,
   and gate the decision on it.

### How stereo depth works (the one piece of geometry to master)

Two cameras a known baseline `b` apart see the same fruit at slightly different
horizontal pixel positions. That difference is the **disparity** `d`. With focal
length `f` (in pixels), depth is:

```
Z = f · b / d
```

Nearer objects have larger disparity; far objects have tiny disparity, which is
why stereo depth degrades with distance and why a *close-range* head is the right
choice for a machine that works within its own wheelbase. Once `Z` is known, the
full 3D point in the camera frame is:

```
X = (u − cx) · Z / f
Y = (v − cy) · Z / f
Z = f · b / d
```

where `(u, v)` is the pixel and `(cx, cy)` the principal point. A fixed
extrinsic transform (a rotation `R` and translation `t` from a one-time
calibration) then maps that point into the robot frame the arm uses:

```
p_robot = R · p_camera + t
```

This chain — pixel → camera 3D → robot 3D — is the single most important
computation in the course, because it is the handoff from "seeing" to "acting."

### The three field failure modes and their mitigations

| Failure mode | Why it breaks naive vision | Mitigation taught here |
|--------------|----------------------------|------------------------|
| **Occlusion** | Fruit is under sprawling vines; the detector sees a sliver | Active canopy clearing (Module 4) *plus* an occlusion gate that defers uncertain picks |
| **Same-color camouflage** | Ripe rind ≈ leaf green; color thresholds fail | Learned features over hand-tuned color; multi-modal fusion (add NIR / depth / texture) |
| **Variable illumination** | Full sun to hard shade within one frame | Training-time domain randomization; HDR or auto-exposure; normalize, don't threshold raw RGB |

### The occlusion gate — a design idea worth dwelling on

A harvester that grabs at a 70%-hidden melon will mis-grasp, bruise fruit, or
crash the gripper into a vine. A better policy: compute an occlusion fraction for
each candidate (e.g., visible mask area vs. expected full-fruit area, or count of
overlapping leaf instances) and **only commit to a pick when occlusion is below a
threshold** (in our case study, on the order of ≤ 34%). Fruit above the gate is
either skipped for a later pass, or handed to the canopy-clearing routine and
re-evaluated. This is a recurring theme: *a good robot knows when not to act.*

### Choosing metrics that match the mission

Students routinely optimize the wrong number. For a harvester:

- **Recall** (did we find the ripe fruit?) drives yield — missed fruit is lost
  revenue.
- **Precision** (were our detections real?) drives wasted cycles and mis-grasps.
- **Localization error** (how far off is the 3D position?) drives grasp success
  directly and is often the true bottleneck even when detection looks great.

A detector with 0.95 mAP and 3 cm localization error may harvest *worse* than a
weaker detector with 1 cm error. Measure the thing that predicts a grasped fruit.

## Grad extension

**Multi-modal fusion.** Read on sensor fusion for agricultural perception, then
write a half-page architecture proposal for fusing RGB, stereo depth, and NIR
reflectance to detect a same-color melon. Address: where in the network features
should fuse (early/mid/late), how to handle a missing modality at inference, and
what a foundation-model image backbone would and would not buy you here.

## Demo or lab

**Lab 2 — Perception on real-ish frames.**
See [`labs/lab-02-perception.md`](../../labs/lab-02-perception.md). Students run a
pretrained detector on a provided image set (melons in canopy under varied
light), then:

1. Compute precision/recall at several confidence thresholds and plot the curve.
2. Take a detection + a depth value and hand-compute the 3D position in the
   camera frame, then transform to the robot frame with a given `R, t`.
3. Implement a simple occlusion metric and set a gate; report how many picks the
   gate defers and argue whether the threshold is well chosen.

No GPU cluster required — the lab runs on a laptop or the course's edge device to
foreshadow Module 3.

## Knowledge check

1. Write the stereo depth equation and explain, physically, why depth accuracy
   falls off with distance.
2. A fruit is detected at pixel `(u, v) = (410, 300)`; depth `Z = 0.85 m`;
   `f = 700 px`, `(cx, cy) = (320, 240)`. Compute `X, Y, Z` in the camera frame.
3. Your detector has excellent mAP but grasp success is poor. Name two perception
   causes and how you'd test for each.
4. Explain the occlusion gate. Why might raising the gate threshold *increase*
   total harvested fruit yet *decrease* fruit quality?
5. For this application, argue whether recall or precision should be weighted more
   heavily, and describe a case where your answer flips.

## Take-home assignment

Using the provided image set, produce a **one-page perception report**: your
precision/recall curve, three representative failure cases (one per failure
mode) with a sentence each on cause and fix, and a recommended operating
confidence threshold with justification. Deliverable:
`assignments/m2-perception-report.md` plus figures.
