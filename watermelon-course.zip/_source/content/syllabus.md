# Syllabus at a Glance

| # | Module | Hrs | Core question it answers |
|---|--------|-----|--------------------------|
| 1 | Harvesting Robotics: The Problem and the System | 3 | Why is heavy-fruit harvest still manual, and what does a machine that fixes it look like? |
| 2 | Seeing the Fruit: Machine Vision and Perception | 5 | How does the robot find a green melon in a green canopy and know where it is in 3D? |
| 3 | Deciding on the Robot: Edge Computing, ML, and AI | 5 | How do we run modern AI on the machine itself, with no cloud, fast enough and cool enough? |
| 4 | Reaching the Fruit: Manipulation and Control | 5 | How does the arm get to the fruit, grasp 5–10 kg without bruising it, and place it — reliably? |
| 5 | Making It One Machine: HW/SW Integration and System Design | 4 | How do vision, compute, drive, and arm become a single dependable system with a real BOM? |
| 6 | Field-Worthy: Testing, Safety, and Deployment | 3 | How do we prove it works, keep people safe, and deploy it ethically on a real farm? |
| 7 | Capstone: Design a Harvesting Subsystem | 3+ | Can the student design and defend an original subsystem? |

Total scheduled contact time ≈ 28 hours. The course is designed to run as a
3–4 week intensive, a half-semester module, or a compressed workshop by
adjusting lab depth. Modules 2–4 are the technical core and should not be cut;
Modules 1, 5, and 6 can be compressed if time is short.

## How each module is structured

Every module file (`content/modules/NN-*.md`) contains the same sections in the
same order, so the material is predictable to teach and easy to diff:

- **Title & duration**
- **Learning outcomes** — measurable, verb-first
- **Core concepts** — the actual technical content, specific to the harvester
- **Grad extension** — the deeper/research-oriented layer for graduate students
- **Demo or lab** — something students *do*, most tied to the browser digital twin
- **Knowledge check** — quiz questions (answers in `assessments/`)
- **Take-home** — an assignment that produces an artifact, building toward the capstone

## The running case study

The course is anchored to one concrete machine so the numbers stay real:

- **Platform:** farm-ng Amiga — a commercially available, open-source, four-wheel
  rover with adjustable track (36–90 in.) and an open tool space beneath the frame.
- **Architecture:** *drive-over* — the rover straddles the crop bed; the fruit
  passes beneath the frame as the machine advances; picking happens at a fixed
  station inside the wheelbase.
- **Manipulator:** a planar **parallel** two-cylinder mechanism whose telescopic
  struts converge on a single gripper node — chosen specifically to minimize
  moving mass and actuated degrees of freedom for a heavy payload.
- **Perception:** front-mounted stereo vision with an occlusion-gated detector.
- **Compute:** fully on-robot edge inference (NVIDIA Jetson-class + platform
  controller), no cloud in the control loop.

Students do not need to build this machine. They study it, simulate it in the
browser digital twin, and in the capstone either extend it or design a
competing subsystem.
