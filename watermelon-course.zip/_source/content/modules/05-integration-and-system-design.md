# Module 5 — Making It One Machine: HW/SW Integration and System Design

**Duration:** 4 hours (2 h lecture · 2 h lab/workshop)

## Learning outcomes

By the end of this module, students can:

1. Draw a hardware architecture for the harvester: sensors, compute, actuation,
   power, and the buses that connect them.
2. Draw a software architecture: nodes, message flow, the supervisory state
   machine, and the real-time boundary.
3. Write measurable design specifications and distinguish functional,
   performance, and constraint requirements.
4. Produce a bill of materials organized by subsystem and reason about cost,
   sourcing, and replaceability.
5. Explain integration hazards — timing, power, EMI, mechanical fit — that only
   appear when subsystems meet.

## Core concepts

### Hardware architecture

The machine is a small distributed system. A workable reference architecture:

- **Mobility:** four-wheel rover (Amiga), hub motors, wheel encoders, RTK-GNSS
  for row following.
- **Sensing:** front stereo camera(s) for detection/localization; optional
  close-range wrist camera for grasp verification; optional NIR module for
  maturity; a solid-state lidar for canopy structure and bumper safety.
- **Compute:** a platform controller ("Brain") for drive, CAN, and safety; a
  Jetson-class edge module for perception and the grasp policy. Split real-time
  control from heavy inference deliberately.
- **Actuation:** two telescopic linear actuators (the parallel struts) with
  encoders; the gripper with load cells and a tactile array; the canopy tool.
- **Power:** platform battery, DC distribution, per-domain fusing; budget peak vs.
  continuous draw, and account for the edge device's thermal load.
- **Buses:** CAN for real-time motor/safety traffic; Ethernet/USB for camera and
  inference data; a ROS 2 bridge tying the high-level nodes together.

The key architectural decision students must be able to defend: **separate the
hard-real-time, safety-critical control plane (CAN, on the Brain) from the
best-effort, compute-heavy perception plane (Ethernet, on the Jetson).** Mixing
them means a slow inference frame can stall a safety loop — unacceptable.

### Software architecture

A ROS 2-style graph is the teaching baseline:

```
[camera driver] → [detector] → [localizer] → [supervisor / state machine]
                                                   │
                    [grasp policy] ← ─ ─ ─ ─ ─ ─ ─ ┤ (commands)
                                                   ▼
                                   [drive controller]  [arm controller]  [safety monitor]
                                                   │        │                 │
                                                   └──────── CAN bus ─────────┘
```

- The **supervisor** owns the mission state machine
  (`DRIVE → STAGE → ALIGN → GRAB → LIFT → SWING → LOWER → RELEASE`) and is the
  single place decisions are made.
- The **safety monitor** runs independently and can halt the machine regardless
  of what the supervisor believes — it is not a state in the mission FSM but a
  parallel guardian (e-stop, bumper lidar, geofence).
- The **real-time boundary** separates nodes that must meet deadlines (drive, arm,
  safety) from those that are best-effort (detection, logging, telemetry).

### Writing specifications that can be tested

A specification that cannot be measured cannot be verified. Teach the discipline
of measurable requirements. Compare:

- Weak: *"The system shall harvest melons quickly and gently."*
- Strong: *"The system shall complete a pick-to-place cycle in ≤ N seconds at a
  rover speed of ≥ V m/s, with visible bruising in ≤ 5% of placed fruit, verified
  by instrumented firmness audit on a ≥ 100-fruit sample."*

The full worked specification lives in
[`specs/design-specification.md`](../../specs/design-specification.md); students
read it, critique it, and in the capstone write their own.

### The bill of materials as an engineering document

A BOM is not a shopping list; it is a design decision made legible. Organized by
subsystem, it reveals where cost and risk concentrate, what is commercial-off-
the-shelf vs. fabricated, and what is a single point of failure. The course BOM
is in [`specs/bill-of-materials.md`](../../specs/bill-of-materials.md). Students
learn to read it critically: *why is the platform the largest line? which item
would you dual-source? what is the cheapest change that most improves reliability?*

### Integration hazards — where good subsystems fail together

The failures that surprise students are emergent, not local:

- **Timing:** a perception frame that is fine in isolation arrives too late once
  the bus is loaded.
- **Power:** simultaneous actuator inrush + inference spike browns out a shared
  rail.
- **EMI:** motor drives inject noise into camera or encoder lines routed beside
  them.
- **Mechanical fit & tolerance:** the arm's real workspace clips the frame that
  CAD said it cleared; cables snag at full stroke.
- **Coordinate frames:** a calibration error between camera and arm frames turns
  a perfect detection into a missed grasp.

The remedy is not heroics but discipline: interface control documents, staged
bring-up (power → buses → sensors → actuation → autonomy), and testing at each
stage before adding the next.

## Grad extension

**Interface control.** Pick one interface in the architecture (e.g., localizer →
supervisor, or supervisor → arm controller) and write a one-page interface
control document: message contents, units, coordinate frame, rate, timing
guarantee, and failure behavior. Graduate students additionally propose a bring-up
test that would catch a frame-calibration error before it reaches the field.

## Demo or lab

**Lab 5 — Architecture and spec workshop.**
See [`labs/lab-05-architecture.md`](../../labs/lab-05-architecture.md). In teams,
students:

1. Redraw the hardware and software architecture for a stated variant (e.g., add
   a second arm, or move to pumpkins) and mark the real-time boundary.
2. Take three weak requirements and rewrite them as measurable specifications.
3. Audit the course BOM: identify the largest cost, one single point of failure,
   and one cost-reducing substitution; defend each in two sentences.

## Knowledge check

1. Why separate the CAN control plane from the Ethernet perception plane? Give a
   concrete failure the separation prevents.
2. The safety monitor is drawn *outside* the mission state machine. Why is that
   architecturally important?
3. Rewrite this as a measurable spec: *"The robot should see fruit well in most
   lighting."*
4. Name three integration hazards that do not appear when subsystems are tested
   alone, and give a mitigation for each.
5. In the BOM, why is buying a commercial platform (rather than fabricating a
   chassis) itself a design decision with downstream consequences?

## Take-home assignment

Produce a **two-page system design packet** for your capstone concept: a hardware
architecture diagram, a software/node diagram with the real-time boundary marked,
and five measurable design specifications (at least one each: functional,
performance, constraint). Deliverable: `assignments/m5-design-packet.md` plus
diagrams. This is a direct down payment on the capstone.
