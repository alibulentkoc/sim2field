# Module 4 — Reaching the Fruit: Manipulation and Control

**Duration:** 5 hours (2.5 h lecture · 2.5 h lab)

## Learning outcomes

By the end of this module, students can:

1. Distinguish serial and parallel manipulator architectures and justify a choice
   for a heavy-payload harvester.
2. Derive the inverse kinematics of the case-study parallel two-cylinder
   mechanism and compute actuator lengths for a target.
3. Identify a mechanism's workspace, singularities, and collision constraints and
   explain how a planner respects them.
4. Explain degree-of-freedom reduction as a co-design outcome — how vehicle
   motion and gripper compliance remove actuated axes.
5. Describe a grasp/place cycle as a state machine and reason about its
   transitions and safety.

## Core concepts

### Serial vs. parallel — and why parallel wins here

A **serial** arm stacks motorized joints; each motor carries the weight of every
joint beyond it, so a heavy end payload demands large motors at the base and the
arm is heavy and compliant. A **parallel** mechanism grounds its actuators to the
frame and drives the end platform through struts, so the moving mass is small and
the structure is stiff. For a 5–10 kg fruit, parallel is the natural fit.

Our case study is a **planar parallel two-cylinder mechanism**: two telescopic
struts, each based on a frame rail, converge on a single gripper node in the
transverse (cross-row) plane. Both actuators are frame-mounted — near-zero motor
mass moves — and the mechanism is stiff enough to swing a heavy melon without
whipping.

### Inverse kinematics — refreshingly direct

For most parallel mechanisms IK is the *easy* direction. Here it is almost
trivial and that is a feature, not a simplification for teaching. Let the gripper
node be at `G = (z, y)` in the transverse plane and let the two strut bases be
`B₁` and `B₂` on the rails. The required strut lengths are just the distances:

```
L₁ = |G − B₁| = √((z − z_B1)² + (y − y_B1)²)
L₂ = |G − B₂| = √((z − z_B2)² + (y − y_B2)²)
```

The actuator lengths *are* the task coordinates — there is no transcendental
solve, no branch ambiguity. Command `(z, y)`, get `(L₁, L₂)`. Students compute
these by hand and then watch the twin do exactly the same thing.

### Workspace, singularities, collisions

Three constraints bound where the node may go, and a real planner enforces all
three:

- **Workspace** = the intersection of the two strut **stroke annuli** (each strut
  has a min and max length). Reachable space is the lens where both annuli
  overlap, and — a nice co-design point — it **scales with the rover's track
  width**, because the bases ride the adjustable rails.
- **Singularities.** When the two struts become nearly collinear, the mechanism
  loses force authority perpendicular to them — a **parallel singularity**. The
  health metric is the **transmission angle** `γ` between the struts at the node;
  the planner keeps `γ` bounded away from 0° and 180° (e.g., warns below ~15°).
  There is also a **flat-singularity** limit near the base line that caps how
  high the node may rise.
- **Collisions.** The payload envelope (fingers + fruit, hanging below the node)
  must clear the frame, wheels, and bin wall during transfer. The planner keeps
  the node inside a **keep-out corridor** — carrying high over obstacles and
  descending only past the bin wall.

A good exercise in engineering judgment: the same widening of the track that
improves agronomic clearance *also* improves `γ`. The course keeps returning to
these coupled decisions.

### Degree-of-freedom reduction as co-design

A naive picker might have a base yaw, a shoulder, an elbow, a wrist, and a
telescoping reach — five actuated axes, five things to fail. The case study
deletes most of them, and *where each axis went* is the lesson:

| Eliminated axis | Absorbed by |
|-----------------|-------------|
| Fore/aft (x) positioning | the **vehicle** — it drives the fruit to a fixed station |
| Along-row (x) fine scatter | **paddle width** — long compliant pads tolerate offset |
| Wrist tilt | a **gravity-plumb** gripper head that hangs level passively |
| Base yaw / lateral transfer | the **in-plane stroke** itself places into the side trailer |

What remains is two prismatic drives plus a grip. Fewer drives means fewer field
failures, simpler control, lower cost, and — because pick and place become the
*same two poses every cycle* — highly repeatable cycle times. This is the single
most important design idea in the module: **actuated complexity is a cost, and
much of it can be designed away by letting the vehicle and passive compliance do
the work.**

### The grasp/place cycle as a state machine

The supervisor sequences the arm through a small, verifiable state machine:

```
DRIVE → STAGE → ALIGN → GRAB → LIFT → SWING → LOWER → RELEASE → (next fruit)
```

Each transition has a guard (a condition that must hold) and a safety
consideration. `LIFT` and `SWING` occur at a height that clears the keep-out
corridor; `GRAB` waits on a force/tactile condition; `RELEASE` only fires over a
valid bin slot. Students reason about what happens if a guard never becomes true
(a stuck cycle) and how the machine should recover.

### Active canopy management (closing the loop with Module 2)

When perception reports a fruit above the occlusion gate, manipulation helps
perception: a front-mounted canopy tool (a rotary brush, an air knife, or passive
lifter fingers) clears leaves in a corridor, and a wrist-mounted air puff clears
residual canopy at the grasp site. A slip clutch and a motor-current limit
protect against vine wrap. This is a concrete example of subsystems cooperating
rather than operating in a strict pipeline.

## Grad extension

**Plan through the constraints.** Given strut stroke limits, base positions, and
a keep-out corridor, write (pseudocode or real) a planner that moves the node
from a pick pose to a drop pose while (a) staying inside both stroke annuli,
(b) keeping `γ` above a threshold, and (c) never entering the keep-out volume
below the carry height. Report the path and where each constraint was active.
Graduate students additionally derive the mechanism's Jacobian and relate its
conditioning to `γ`.

## Demo or lab

**Lab 4 — Kinematics and the constraint envelope.**
See [`labs/lab-04-manipulation.md`](../../labs/lab-04-manipulation.md). In the
digital twin:

1. Drag the gripper node and read `L₁, L₂` and `γ` live; map the reachable
   workspace by finding where the node stops moving (stroke limits).
2. Widen the track and observe both the workspace growth and the improvement in
   `γ` at the drop pose — quantify both.
3. Force a near-singular configuration and describe what the telemetry shows and
   why the planner would avoid it.
4. Step the state machine through one full cycle and annotate each guard.

## Knowledge check

1. Give two physical reasons a parallel mechanism suits a 5–10 kg payload better
   than a serial arm.
2. Bases at `B₁ = (−0.85, 1.75)` and `B₂ = (0.85, 1.75)` m; node target
   `G = (0.0, 0.45)`. Compute `L₁` and `L₂`.
3. Define the transmission angle `γ`. What physically goes wrong as `γ → 0`, and
   how does the planner respond?
4. For each eliminated actuated axis in the case study, name what absorbed its
   function.
5. In the state machine, why must `LIFT` and `SWING` share a common carry height?
   What collision does that prevent?

## Take-home assignment

Produce a **one-page manipulation analysis** of the case-study mechanism (or your
own variant): the IK equations, a sketch or plot of the reachable workspace, the
location of its singularities, and a labeled state machine for one grasp/place
cycle with the guard on each transition. Deliverable:
`assignments/m4-manipulation-analysis.md` plus figures.
